import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { AdminApiService } from '../../core/admin-api.service';
import { Activity, RoleOption } from '../../core/models';
import { Icon } from '../../shared/icon';
import { ToastService } from '../../shared/toast.service';
import { ActivityFeed } from '../shared/activity-feed';
import { errorMessage } from '../shared/errors';

/** Full activity log (spatie/laravel-activitylog) with filters. */
@Component({
  selector: 'app-activity-log',
  imports: [Icon, ActivityFeed],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="a-page-header">
      <div>
        <h1>Historial de actividad</h1>
        <p>Todo lo que se hace en el panel queda registrado: quién, qué y cuándo.</p>
      </div>
    </div>

    <div class="a-toolbar">
      <form (submit)="$event.preventDefault(); query = q.value.trim(); load(1)">
        <app-icon name="search" [size]="17" class="search-icon" />
        <input #q type="search" class="input search-input" placeholder="Buscar en el historial…" aria-label="Buscar en el historial" />
      </form>
      <select class="input" aria-label="Tipo" (change)="log = $any($event.target).value; load(1)">
        <option value="">Todas las secciones</option>
        @for (l of logs(); track l.value) {
          <option [value]="l.value">{{ l.label }}</option>
        }
      </select>
      <select class="input" aria-label="Usuario" (change)="user = +$any($event.target).value || null; load(1)">
        <option value="">Todos los usuarios</option>
        @for (u of users(); track u.id) {
          <option [value]="u.id">{{ u.name }}</option>
        }
      </select>
    </div>

    <section class="a-card">
      @if (loading()) {
        @for (i of [1, 2, 3, 4, 5]; track i) {
          <div class="sk-row"><span class="skeleton" style="width: 38px; height: 38px; border-radius: 50%"></span><span class="skeleton" style="flex: 1; height: 14px"></span></div>
        }
      } @else {
        <app-activity-feed [items]="items()" />
      }
    </section>

    @if (lastPage() > 1) {
      <div class="a-pagination">
        <span>{{ total() }} registros · página {{ page() }} de {{ lastPage() }}</span>
        <div>
          <button type="button" class="btn btn--outline btn--sm" [disabled]="page() <= 1" (click)="load(page() - 1)">Anterior</button>
          <button type="button" class="btn btn--outline btn--sm" [disabled]="page() >= lastPage()" (click)="load(page() + 1)">Siguiente</button>
        </div>
      </div>
    }
  `,
  styles: `
    .sk-row { display: flex; align-items: center; gap: 0.8rem; padding: 0.75rem 0; }
  `,
})
export class ActivityLog implements OnInit {
  private api = inject(AdminApiService);
  private toast = inject(ToastService);

  protected readonly items = signal<Activity[]>([]);
  protected readonly logs = signal<RoleOption[]>([]);
  protected readonly users = signal<{ id: number; name: string }[]>([]);
  protected readonly loading = signal(true);
  protected readonly page = signal(1);
  protected readonly lastPage = signal(1);
  protected readonly total = signal(0);

  protected query = '';
  protected log = '';
  protected user: number | null = null;

  ngOnInit() {
    this.load(1);
  }

  protected load(page: number) {
    this.loading.set(true);
    this.api.activity({ q: this.query, log: this.log, user: this.user, page }).subscribe({
      next: (res) => {
        this.items.set(res.data);
        this.logs.set(res.logs);
        this.users.set(res.users);
        this.page.set(res.meta.current_page);
        this.lastPage.set(res.meta.last_page);
        this.total.set(res.meta.total);
        this.loading.set(false);
      },
      error: (e) => {
        this.loading.set(false);
        this.toast.error(errorMessage(e));
      },
    });
  }
}
