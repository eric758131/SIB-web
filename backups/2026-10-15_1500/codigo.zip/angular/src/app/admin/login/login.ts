import { ChangeDetectionStrategy, Component, inject, input, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';
import { HERO_IMAGE, LOGO_URL } from '../../core/site-content';
import { Icon } from '../../shared/icon';
import { queryText } from '../../shared/route-input';
import { errorMessage } from '../shared/errors';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, RouterLink, Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="login">
      <aside class="visual" [style.background-image]="'url(' + image + ')'">
        <div class="visual-inner">
          <a routerLink="/" class="brand">
            <img [src]="logo" alt="" width="52" height="52" />
            <span>SIB La Paz <small>Sociedad de Ingenieros de Bolivia</small></span>
          </a>
          <div class="quote">
            <h2>Innovación que forja el desarrollo</h2>
            <p>Gestiona las noticias, los mensajes y los usuarios del sitio oficial de la SIB Departamental La Paz.</p>
            <ul>
              <li><app-icon name="check" [size]="15" [stroke]="2.4" /> Noticias, mensajes y usuarios en un solo lugar</li>
              <li><app-icon name="check" [size]="15" [stroke]="2.4" /> Roles y permisos por usuario</li>
              <li><app-icon name="check" [size]="15" [stroke]="2.4" /> Historial de cada cambio</li>
            </ul>
          </div>
        </div>
      </aside>

      <main class="panel">
        <div class="box">
          <a routerLink="/" class="mobile-brand">
            <img [src]="logo" alt="" width="56" height="56" />
          </a>
          <h1>Bienvenido de nuevo</h1>
          <p class="sub">Ingresa con tu usuario o correo y tu contraseña.</p>

          @if (expirada()) {
            <div class="alert alert--info"><app-icon name="clock" [size]="16" /> Tu sesión expiró. Vuelve a iniciar sesión.</div>
          }
          @if (error()) {
            <div class="alert alert--error" role="alert"><app-icon name="close" [size]="16" /> {{ error() }}</div>
          }

          <form [formGroup]="form" (ngSubmit)="submit()" novalidate>
            <div class="field">
              <label for="login">Usuario o correo electrónico</label>
              <div class="input-icon">
                <app-icon name="user" [size]="18" />
                <input id="login" formControlName="login" autocomplete="username" placeholder="tu@correo.com" autofocus />
              </div>
            </div>
            <div class="field">
              <label for="password">Contraseña</label>
              <div class="input-icon">
                <app-icon name="lock" [size]="18" />
                <input id="password" [type]="show() ? 'text' : 'password'" formControlName="password" autocomplete="current-password" placeholder="••••••••" />
                <button type="button" class="eye" (click)="show.set(!show())" [attr.aria-label]="show() ? 'Ocultar contraseña' : 'Mostrar contraseña'">
                  <app-icon [name]="show() ? 'x' : 'eye'" [size]="17" />
                </button>
              </div>
            </div>
            <button type="submit" class="btn submit" [disabled]="loading()">
              @if (loading()) {
                <span class="mini-spin"></span> Ingresando…
              } @else {
                Iniciar sesión <app-icon name="arrow-right" [size]="18" />
              }
            </button>
          </form>

          <a routerLink="/" class="back"><app-icon name="chevron-left" [size]="15" /> Volver al sitio</a>
        </div>
      </main>
    </div>
  `,
  styles: `
    .login { display: grid; grid-template-columns: 1.1fr 1fr; min-height: 100vh; background: #fff; }

    .visual {
      position: relative;
      display: flex;
      background: var(--c-dark) center / cover;
      color: #fff;
      isolation: isolate;
      &::before {
        content: '';
        position: absolute;
        inset: 0;
        z-index: -1;
        background:
          radial-gradient(rgba(127, 220, 185, 0.18) 1px, transparent 1px) 0 0 / 22px 22px,
          linear-gradient(160deg, rgba(1, 17, 12, 0.92), rgba(21, 129, 96, 0.78));
      }
    }
    .visual-inner { display: flex; flex-direction: column; justify-content: space-between; padding: clamp(2rem, 5vw, 3.5rem); width: 100%; }
    .brand {
      display: inline-flex;
      align-items: center;
      gap: 0.75rem;
      color: #fff;
      font: 600 1.6rem/1 var(--f-heading);
      img { width: 52px; height: 52px; padding: 4px; background: #fff; border-radius: 50%; object-fit: contain; }
      small { display: block; margin-top: 0.3rem; font: 600 0.68rem var(--f-body); letter-spacing: 0.14em; text-transform: uppercase; color: #7fdcb9; }
      &:hover { color: #fff; }
    }
    .quote {
      max-width: 480px;
      h2 { color: #fff; font-size: clamp(2.2rem, 4vw, 3.2rem); line-height: 1.1; margin-bottom: 1rem; }
      p { color: #cfe5dd; font-size: 1.05rem; }
      ul { list-style: none; margin: 1.5rem 0 0; padding: 0; display: grid; gap: 0.6rem; }
      li { display: flex; align-items: center; gap: 0.6rem; color: #e5f3ee; font-weight: 500; }
      app-icon { display: grid; place-items: center; width: 24px; height: 24px; border-radius: 50%; background: rgba(127, 220, 185, 0.25); color: #a6ead0; }
    }

    .panel { display: grid; place-items: center; padding: 2rem 1.5rem; background: linear-gradient(180deg, #fff, #f5f9f7); }
    .box { width: 100%; max-width: 400px; animation: rise 0.5s ease both; }
    .mobile-brand { display: none; margin-bottom: 1rem; img { width: 56px; height: 56px; } }
    h1 { font: 700 1.75rem var(--f-body); letter-spacing: -0.02em; text-transform: none; margin: 0 0 0.35rem; }
    .sub { color: #6b7270; font-size: 0.95rem; margin-bottom: 1.75rem; }
    .alert { display: flex; align-items: center; gap: 0.5rem; }

    .input-icon {
      position: relative;
      > app-icon { position: absolute; left: 0.9rem; top: 50%; transform: translateY(-50%); color: #9aa29f; pointer-events: none; }
      input { padding-left: 2.6rem !important; padding-block: 0.85rem !important; border-radius: 10px !important; }
      &:focus-within > app-icon { color: var(--c-primary); }
    }
    .eye { position: absolute; right: 0.5rem; top: 50%; transform: translateY(-50%); display: grid; place-items: center; width: 34px; height: 34px; border: 0; border-radius: 8px; background: none; color: #8a918f; cursor: pointer; &:hover { background: var(--c-soft); color: var(--c-primary); } }

    .submit { width: 100%; margin-top: 0.75rem; padding-block: 0.95rem; border-radius: 10px; font-size: 1rem; }
    .mini-spin { width: 16px; height: 16px; border: 2px solid rgba(255, 255, 255, 0.4); border-top-color: #fff; border-radius: 50%; animation: spin 0.8s linear infinite; }
    .back { display: inline-flex; align-items: center; gap: 0.25rem; margin-top: 1.5rem; font-size: 0.9rem; color: #6b7270; &:hover { color: var(--c-primary); } }

    @keyframes rise { from { opacity: 0; transform: translateY(14px); } }

    @media (max-width: 900px) {
      .login { grid-template-columns: 1fr; }
      .visual { display: none; }
      .mobile-brand { display: inline-block; }
    }
  `,
})
export class Login {
  private auth = inject(AuthService);
  private router = inject(Router);

  readonly volver = input('', { transform: queryText() });
  readonly expirada = input('', { transform: queryText() });

  protected readonly logo = LOGO_URL;
  protected readonly image = HERO_IMAGE;
  protected readonly loading = signal(false);
  protected readonly show = signal(false);
  protected readonly error = signal<string | null>(null);

  protected readonly form = inject(FormBuilder).nonNullable.group({
    login: ['', Validators.required],
    password: ['', Validators.required],
  });

  protected submit() {
    if (this.form.invalid) {
      this.error.set('Ingresa tu usuario y contraseña.');
      return;
    }

    this.loading.set(true);
    this.error.set(null);
    const { login, password } = this.form.getRawValue();

    this.auth.login(login, password).subscribe({
      next: () => {
        const target = this.volver();
        this.router.navigateByUrl(target.startsWith('/admin') ? target : '/admin');
      },
      error: (err) => {
        this.error.set(errorMessage(err, 'No se pudo iniciar sesión.'));
        this.loading.set(false);
      },
    });
  }
}
