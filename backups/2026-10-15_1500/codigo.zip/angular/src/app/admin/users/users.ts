import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AdminApiService } from '../../core/admin-api.service';
import { AuthService } from '../../core/auth.service';
import { RoleOption, User } from '../../core/models';
import { ConfirmService } from '../../shared/confirm.service';
import { Icon } from '../../shared/icon';
import { ToastService } from '../../shared/toast.service';
import { avatarColor, initials } from '../shared/avatar';
import { FieldErrors, errorMessage, fieldErrors } from '../shared/errors';

interface UserFormState {
  username: string;
  name: string;
  email: string;
  role: string;
  password: string;
  password_confirmation: string;
}

const EMPTY: UserFormState = { username: '', name: '', email: '', role: 'editor', password: '', password_confirmation: '' };
const SYSTEM_ROLES = ['administrator', 'editor', 'author'];

/** Site accounts and their panel role (spatie/laravel-permission). */
@Component({
  selector: 'app-users',
  imports: [DatePipe, Icon, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './users.html',
  styleUrl: './users.scss',
})
export class Users implements OnInit {
  private api = inject(AdminApiService);
  private toast = inject(ToastService);
  private confirm = inject(ConfirmService);
  protected readonly auth = inject(AuthService);

  protected readonly users = signal<User[]>([]);
  protected readonly roles = signal<RoleOption[]>([]);
  protected readonly loading = signal(true);
  protected readonly roleFilter = signal('');

  protected readonly modalOpen = signal(false);
  protected readonly editing = signal<User | null>(null);
  protected readonly form = signal<UserFormState>({ ...EMPTY });
  protected readonly errors = signal<FieldErrors>({});
  protected readonly saving = signal(false);
  protected readonly showPassword = signal(false);
  private query = '';

  protected readonly visible = computed(() => {
    const filter = this.roleFilter();
    if (!filter) return this.users();
    return this.users().filter((u) => (filter === 'none' ? !u.role : u.role === filter));
  });

  protected readonly roleCounts = computed(() => {
    const counts: Record<string, number> = {};
    for (const u of this.users()) counts[u.role ?? 'none'] = (counts[u.role ?? 'none'] ?? 0) + 1;
    return counts;
  });

  protected readonly avatarColor = avatarColor;
  protected readonly initials = initials;

  ngOnInit() {
    this.load();
  }

  protected load() {
    this.api.users(this.query).subscribe({
      next: (res) => {
        this.users.set(res.data);
        this.roles.set(res.roles);
        this.loading.set(false);
      },
      error: (e) => {
        this.loading.set(false);
        this.toast.error(errorMessage(e));
      },
    });
  }

  protected search(q: string) {
    this.query = q.trim();
    this.load();
  }

  protected badgeClass(role: string | null) {
    if (!role) return 'none';
    return SYSTEM_ROLES.includes(role) ? role : 'custom';
  }

  protected set<K extends keyof UserFormState>(key: K, value: UserFormState[K]) {
    this.form.update((f) => ({ ...f, [key]: value }));
  }

  protected create() {
    this.editing.set(null);
    this.form.set({ ...EMPTY });
    this.errors.set({});
    this.showPassword.set(false);
    this.modalOpen.set(true);
  }

  protected edit(user: User) {
    this.editing.set(user);
    this.form.set({ ...EMPTY, username: user.username, name: user.name, email: user.email, role: user.role ?? '' });
    this.errors.set({});
    this.showPassword.set(false);
    this.modalOpen.set(true);
  }

  protected generatePassword() {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%';
    const values = crypto.getRandomValues(new Uint32Array(14));
    const password = Array.from(values, (v) => chars[v % chars.length]).join('');
    this.form.update((f) => ({ ...f, password, password_confirmation: password }));
    this.showPassword.set(true);
  }

  protected save() {
    const f = this.form();
    const editing = this.editing();

    const local: FieldErrors = {};
    if (!editing && !f.username.trim()) local['username'] = 'El nombre de usuario es obligatorio.';
    if (!f.name.trim()) local['name'] = 'El nombre es obligatorio.';
    if (!f.email.trim()) local['email'] = 'El correo es obligatorio.';
    if (!editing && f.password.length < 8) local['password'] = 'La contraseña debe tener al menos 8 caracteres.';
    if (f.password && f.password !== f.password_confirmation) local['password'] = 'Las contraseñas no coinciden.';
    this.errors.set(local);
    if (Object.keys(local).length) return;

    const data: Record<string, unknown> = { name: f.name.trim(), email: f.email.trim(), role: f.role };
    if (!editing) data['username'] = f.username.trim();
    if (f.password) {
      data['password'] = f.password;
      data['password_confirmation'] = f.password_confirmation;
    }

    this.saving.set(true);
    (editing ? this.api.updateUser(editing.id, data) : this.api.createUser(data)).subscribe({
      next: ({ data: user }) => {
        this.saving.set(false);
        this.modalOpen.set(false);
        this.toast.success(editing ? `Usuario «${user.name}» actualizado.` : `Usuario «${user.name}» creado.`);
        if (user.id === this.auth.user()?.id) this.auth.refresh();
        this.load();
      },
      error: (e) => {
        this.saving.set(false);
        this.errors.set(fieldErrors(e));
        if (!Object.keys(fieldErrors(e)).length) this.toast.error(errorMessage(e));
      },
    });
  }

  protected async remove(user: User) {
    const ok = await this.confirm.ask({
      title: `¿Eliminar a «${user.name}»?`,
      message: 'La cuenta se eliminará de forma permanente. Sus publicaciones pasarán a tu nombre.',
      confirmText: 'Eliminar usuario',
      danger: true,
    });
    if (!ok) return;

    this.api.deleteUser(user.id).subscribe({
      next: () => {
        this.toast.success('Usuario eliminado.');
        this.load();
      },
      error: (e) => this.toast.error(errorMessage(e)),
    });
  }
}
