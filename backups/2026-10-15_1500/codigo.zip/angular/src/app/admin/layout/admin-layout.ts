import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { filter } from 'rxjs';
import { AdminApiService } from '../../core/admin-api.service';
import { AuthService, Permission } from '../../core/auth.service';
import { LOGO_URL, VISADOS_LINKS } from '../../core/site-content';
import { Icon } from '../../shared/icon';
import { avatarColor, initials } from '../shared/avatar';

interface AdminNavItem {
  label: string;
  path: string;
  icon: string;
  exact?: boolean;
  permission?: Permission;
  badge?: () => number;
}

interface AdminNavGroup {
  title: string;
  items: AdminNavItem[];
}

@Component({
  selector: 'app-admin-layout',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './admin-layout.html',
  styleUrl: './admin-layout.scss',
  host: { '(document:click)': 'userMenuOpen.set(false)' },
})
export class AdminLayout {
  protected readonly auth = inject(AuthService);
  private api = inject(AdminApiService);

  protected readonly logo = LOGO_URL;
  protected readonly systems = VISADOS_LINKS;
  protected readonly year = new Date().getFullYear();
  protected readonly sidebarOpen = signal(false);
  protected readonly userMenuOpen = signal(false);
  protected readonly unread = signal(0);

  private readonly groups: AdminNavGroup[] = [
    {
      title: 'General',
      items: [{ label: 'Escritorio', path: '/admin', icon: 'home', exact: true }],
    },
    {
      title: 'Contenido',
      items: [
        { label: 'Publicaciones', path: '/admin/publicaciones', icon: 'newspaper', permission: 'publicaciones.crear' },
        { label: 'Medios', path: '/admin/medios', icon: 'image' },
        { label: 'Categorías', path: '/admin/categorias', icon: 'tag', permission: 'categorias.gestionar' },
      ],
    },
    {
      title: 'Comunicación',
      items: [
        { label: 'Mensajes', path: '/admin/mensajes', icon: 'inbox', permission: 'mensajes.gestionar', badge: () => this.unread() },
      ],
    },
    {
      title: 'Administración',
      items: [
        { label: 'Usuarios', path: '/admin/usuarios', icon: 'users', permission: 'usuarios.gestionar' },
        { label: 'Roles y permisos', path: '/admin/roles', icon: 'key', permission: 'roles.gestionar' },
        { label: 'Actividad', path: '/admin/actividad', icon: 'activity', permission: 'actividad.ver' },
      ],
    },
  ];

  protected readonly nav = computed(() => {
    this.auth.user(); // re-evaluate when permissions change
    return this.groups
      .map((g) => ({ ...g, items: g.items.filter((i) => !i.permission || this.auth.can(i.permission)) }))
      .filter((g) => g.items.length);
  });

  protected readonly initials = computed(() => initials(this.auth.user()?.name));
  protected readonly avatarColor = computed(() => avatarColor(this.auth.user()?.id ?? 0));

  constructor() {
    inject(Router)
      .events.pipe(
        filter((e) => e instanceof NavigationEnd),
        takeUntilDestroyed(),
      )
      .subscribe(() => {
        this.sidebarOpen.set(false);
        this.refreshUnread();
      });
  }

  protected toggleUserMenu(event: Event) {
    event.stopPropagation();
    this.userMenuOpen.update((v) => !v);
  }

  private refreshUnread() {
    if (!this.auth.can('mensajes.gestionar')) return;
    this.api.messages({ status: 'unread', page: 1 }).subscribe({
      next: (res) => this.unread.set(res.counts['unread'] ?? 0),
      error: () => undefined,
    });
  }
}
