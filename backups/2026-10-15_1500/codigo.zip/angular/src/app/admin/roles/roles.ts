import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { AdminApiService } from '../../core/admin-api.service';
import { AuthService } from '../../core/auth.service';
import { PermissionDef, Role } from '../../core/models';
import { ConfirmService } from '../../shared/confirm.service';
import { Icon } from '../../shared/icon';
import { ToastService } from '../../shared/toast.service';
import { errorMessage } from '../shared/errors';

/** Roles and permissions (spatie/laravel-permission). */
@Component({
  selector: 'app-roles',
  imports: [Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './roles.html',
  styleUrl: './roles.scss',
})
export class Roles implements OnInit {
  private api = inject(AdminApiService);
  private auth = inject(AuthService);
  private toast = inject(ToastService);
  private confirm = inject(ConfirmService);

  protected readonly roles = signal<Role[]>([]);
  protected readonly permissions = signal<PermissionDef[]>([]);
  protected readonly loading = signal(true);
  protected readonly saving = signal(false);

  /** Role being edited, or "new" for the create form. */
  protected readonly selectedId = signal<number | 'new' | null>(null);
  protected readonly name = signal('');
  protected readonly checked = signal<Set<string>>(new Set());

  protected readonly selected = computed(() => {
    const id = this.selectedId();
    return typeof id === 'number' ? (this.roles().find((r) => r.id === id) ?? null) : null;
  });
  protected readonly isNew = computed(() => this.selectedId() === 'new');
  protected readonly locked = computed(() => this.selected()?.name === 'administrator');

  protected readonly groups = computed(() => {
    const map = new Map<string, PermissionDef[]>();
    for (const p of this.permissions()) {
      map.set(p.group, [...(map.get(p.group) ?? []), p]);
    }
    return [...map.entries()].map(([title, items]) => ({ title, items }));
  });

  protected readonly dirty = computed(() => {
    const role = this.selected();
    if (this.isNew()) return true;
    if (!role) return false;
    const current = this.checked();
    return (
      role.label !== this.name() && !role.is_system
    ) || role.permissions.length !== current.size || role.permissions.some((p) => !current.has(p));
  });

  ngOnInit() {
    this.load();
  }

  private load(selectId?: number) {
    this.api.roles().subscribe({
      next: (res) => {
        this.roles.set(res.roles);
        this.permissions.set(res.permissions);
        this.loading.set(false);
        const target = selectId ?? (typeof this.selectedId() === 'number' ? (this.selectedId() as number) : res.roles[0]?.id);
        if (target) this.select(res.roles.find((r) => r.id === target) ?? res.roles[0]);
      },
      error: (e) => {
        this.loading.set(false);
        this.toast.error(errorMessage(e));
      },
    });
  }

  protected select(role: Role) {
    this.selectedId.set(role.id);
    this.name.set(role.label);
    this.checked.set(new Set(role.permissions));
  }

  protected startNew() {
    this.selectedId.set('new');
    this.name.set('');
    this.checked.set(new Set(['publicaciones.crear', 'medios.subir']));
  }

  protected toggle(permission: string, on: boolean) {
    this.checked.update((set) => {
      const next = new Set(set);
      if (on) next.add(permission);
      else next.delete(permission);
      return next;
    });
  }

  protected toggleGroup(items: PermissionDef[], on: boolean) {
    this.checked.update((set) => {
      const next = new Set(set);
      for (const p of items) {
        if (on) next.add(p.name);
        else next.delete(p.name);
      }
      return next;
    });
  }

  protected groupState(items: PermissionDef[]) {
    const count = items.filter((p) => this.checked().has(p.name)).length;
    return count === 0 ? 'none' : count === items.length ? 'all' : 'some';
  }

  protected save() {
    const role = this.selected();
    const name = role?.is_system ? role.name : this.name().trim();
    if (!name) {
      this.toast.error('Escribe un nombre para el rol.');
      return;
    }

    const data = { name, permissions: [...this.checked()] };
    this.saving.set(true);

    (role ? this.api.updateRole(role.id, data) : this.api.createRole(data)).subscribe({
      next: (saved) => {
        this.saving.set(false);
        this.toast.success(role ? `Permisos de «${saved.label}» actualizados.` : `Rol «${saved.label}» creado.`);
        // Our own role may have changed: refresh our permissions.
        if (this.auth.user()?.role === saved.name) this.auth.refresh();
        this.load(saved.id);
      },
      error: (e) => {
        this.saving.set(false);
        this.toast.error(errorMessage(e));
      },
    });
  }

  protected async remove(role: Role) {
    const ok = await this.confirm.ask({
      title: `¿Eliminar el rol «${role.label}»?`,
      message: 'Esta acción no se puede deshacer.',
      confirmText: 'Eliminar rol',
      danger: true,
    });
    if (!ok) return;

    this.api.deleteRole(role.id).subscribe({
      next: () => {
        this.toast.success('Rol eliminado.');
        this.selectedId.set(null);
        this.load();
      },
      error: (e) => this.toast.error(errorMessage(e)),
    });
  }
}
