import { ChangeDetectionStrategy, Component, OnInit, computed, inject, input, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { AdminApiService } from '../../core/admin-api.service';
import { AuthService } from '../../core/auth.service';
import { Activity, Category, Media, Post, PostInput } from '../../core/models';
import { ConfirmService } from '../../shared/confirm.service';
import { Icon } from '../../shared/icon';
import { ToastService } from '../../shared/toast.service';
import { ActivityFeed } from '../shared/activity-feed';
import { FieldErrors, STATUS_LABELS, errorMessage, fieldErrors } from '../shared/errors';
import { MediaPicker } from '../shared/media-picker';
import { RichEditor } from '../shared/rich-editor';

/** Value for <input type="datetime-local"> in the browser's time zone. */
function toLocalInput(iso: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

@Component({
  selector: 'app-post-form',
  imports: [RouterLink, DatePipe, Icon, RichEditor, MediaPicker, ActivityFeed],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './post-form.html',
  styleUrl: './post-form.scss',
})
export class PostForm implements OnInit {
  private api = inject(AdminApiService);
  private router = inject(Router);
  private toast = inject(ToastService);
  private confirm = inject(ConfirmService);
  protected readonly auth = inject(AuthService);

  /** Route param; undefined for "nueva". */
  readonly id = input<string>();

  protected readonly statusLabels = STATUS_LABELS;
  protected readonly loading = signal(false);
  protected readonly saving = signal(false);
  protected readonly errors = signal<FieldErrors>({});
  protected readonly loadError = signal<string | null>(null);
  protected readonly pickerOpen = signal(false);

  protected readonly post = signal<Post | null>(null);
  protected readonly history = signal<Activity[]>([]);
  protected readonly categories = signal<Category[]>([]);

  // Form state
  protected readonly title = signal('');
  protected readonly slug = signal('');
  protected readonly content = signal('');
  protected readonly excerpt = signal('');
  protected readonly publishedAt = signal('');
  protected readonly selectedCategories = signal<number[]>([]);
  protected readonly thumbnailId = signal<number | null>(null);
  protected readonly thumbnailUrl = signal<string | null>(null);

  protected readonly newCategory = signal('');

  protected readonly isNew = computed(() => !this.id());
  protected readonly isPublished = computed(() => ['publish', 'future'].includes(this.post()?.status ?? ''));
  protected readonly canPublish = computed(() => {
    this.auth.user();
    return this.auth.can('publicaciones.publicar');
  });
  protected readonly wordCount = computed(() => {
    const text = this.content().replace(/<[^>]*>/g, ' ').replace(/&nbsp;/g, ' ').trim();
    return text ? text.split(/\s+/).length : 0;
  });
  protected readonly readingMinutes = computed(() => Math.max(1, Math.round(this.wordCount() / 200)));

  ngOnInit() {
    this.api.categories().subscribe({ next: (c) => this.categories.set(c) });

    const id = Number(this.id());
    if (!id) return;

    // Message carried over from the "new post" screen after the first save.
    const saved = (history.state as { saved?: string } | null)?.saved;
    if (saved) this.toast.success(saved);

    this.loading.set(true);
    this.api.post(id).subscribe({
      next: ({ data, history }) => {
        this.fill(data);
        this.history.set(history ?? []);
        this.loading.set(false);
      },
      error: (e) => {
        this.loadError.set(errorMessage(e, 'No se encontró la publicación.'));
        this.loading.set(false);
      },
    });
  }

  private fill(post: Post) {
    this.post.set(post);
    this.title.set(post.title);
    this.slug.set(post.slug);
    this.content.set(post.content ?? '');
    this.excerpt.set(post.manual_excerpt ?? '');
    this.publishedAt.set(post.status === 'draft' ? '' : toLocalInput(post.published_at));
    this.selectedCategories.set(post.categories.map((c) => c.id));
    this.thumbnailId.set(post.thumbnail_id);
    this.thumbnailUrl.set(post.thumbnail_id ? post.cover_image : null);
  }

  protected toggleCategory(id: number, checked: boolean) {
    this.selectedCategories.update((ids) => (checked ? [...ids, id] : ids.filter((x) => x !== id)));
  }

  protected addCategory() {
    const name = this.newCategory().trim();
    if (!name) return;
    this.api.createCategory({ name }).subscribe({
      next: (cat) => {
        this.categories.update((list) => [...list, cat].sort((a, b) => a.name.localeCompare(b.name)));
        this.selectedCategories.update((ids) => [...ids, cat.id]);
        this.newCategory.set('');
        this.toast.success(`Categoría «${cat.name}» creada.`);
      },
      error: (e) => this.toast.error(errorMessage(e)),
    });
  }

  protected setThumbnail(media: Media) {
    this.thumbnailId.set(media.id);
    this.thumbnailUrl.set(media.url);
    this.pickerOpen.set(false);
  }

  protected removeThumbnail() {
    this.thumbnailId.set(null);
    this.thumbnailUrl.set(null);
  }

  protected save(status: PostInput['status']) {
    const input: PostInput = {
      title: this.title().trim(),
      slug: this.slug().trim() || null,
      content: this.content(),
      excerpt: this.excerpt().trim() || null,
      status,
      published_at: this.publishedAt() ? new Date(this.publishedAt()).toISOString() : null,
      categories: this.selectedCategories(),
      thumbnail_id: this.thumbnailId(),
    };

    const local: FieldErrors = {};
    if (!input.title) local['title'] = 'El título es obligatorio.';
    if (!input.content.replace(/<[^>]*>|&nbsp;|\s/g, '') && !/<img/i.test(input.content)) local['content'] = 'Escribe el contenido de la publicación.';
    this.errors.set(local);
    if (Object.keys(local).length) {
      this.toast.error(Object.values(local)[0]);
      return;
    }

    this.saving.set(true);

    const post = this.post();
    const request = post ? this.api.updatePost(post.id, input) : this.api.createPost(input);

    request.subscribe({
      next: ({ data, history }) => {
        this.saving.set(false);
        this.fill(data);
        this.history.set(history ?? []);
        const text =
          data.status === 'publish' ? 'Publicación publicada.'
          : data.status === 'future' ? 'Publicación programada.'
          : data.status === 'pending' ? 'Enviada a revisión.'
          : 'Borrador guardado.';
        if (post) this.toast.success(text);
        else this.router.navigate(['/admin/publicaciones', data.id], { replaceUrl: true, state: { saved: text } });
      },
      error: (e) => {
        this.saving.set(false);
        this.errors.set(fieldErrors(e));
        this.toast.error(errorMessage(e, 'No se pudo guardar la publicación.'));
      },
    });
  }

  protected async trash() {
    const post = this.post();
    if (!post) return;
    const ok = await this.confirm.ask({
      title: '¿Mover a la papelera?',
      message: 'La publicación dejará de verse en el sitio. Podrás restaurarla desde la papelera.',
      confirmText: 'Mover a la papelera',
      danger: true,
    });
    if (!ok) return;

    this.api.trashPost(post.id).subscribe({
      next: () => {
        this.toast.success('Publicación movida a la papelera.');
        this.router.navigate(['/admin/publicaciones']);
      },
      error: (e) => this.toast.error(errorMessage(e)),
    });
  }
}
