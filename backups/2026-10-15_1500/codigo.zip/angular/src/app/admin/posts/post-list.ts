import { ChangeDetectionStrategy, Component, computed, inject, input, numberAttribute } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { Observable, Subject, catchError, map, merge, of, startWith, switchMap } from 'rxjs';
import { AdminApiService } from '../../core/admin-api.service';
import { AuthService } from '../../core/auth.service';
import { Paginated, Post } from '../../core/models';
import { ConfirmService } from '../../shared/confirm.service';
import { Icon } from '../../shared/icon';
import { queryText } from '../../shared/route-input';
import { ToastService } from '../../shared/toast.service';
import { STATUS_LABELS, errorMessage } from '../shared/errors';

type ListResult = Paginated<Post> & { counts: Record<string, number> };

@Component({
  selector: 'app-post-list',
  imports: [RouterLink, DatePipe, Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './post-list.html',
})
export class PostList {
  private api = inject(AdminApiService);
  private router = inject(Router);
  private toast = inject(ToastService);
  private confirm = inject(ConfirmService);
  protected readonly auth = inject(AuthService);

  // Query params
  readonly estado = input('all', { transform: queryText('all') });
  readonly buscar = input('', { transform: queryText() });
  readonly categoria = input(null, { transform: (v: unknown) => (v ? numberAttribute(v) : null) });
  readonly pagina = input(1, { transform: (v: unknown) => numberAttribute(v, 1) });

  protected readonly statusLabels = STATUS_LABELS;
  protected readonly tabs = [
    { value: 'all', label: 'Todas' },
    { value: 'publish', label: 'Publicadas' },
    { value: 'draft', label: 'Borradores' },
    { value: 'pending', label: 'Pendientes' },
    { value: 'future', label: 'Programadas' },
    { value: 'trash', label: 'Papelera' },
  ];

  protected readonly categories = toSignal(this.api.categories().pipe(catchError(() => of([]))), { initialValue: [] });

  private readonly reload$ = new Subject<void>();
  private readonly filters = computed(() => ({
    status: this.estado(),
    q: this.buscar(),
    category: this.categoria(),
    page: this.pagina() || 1,
  }));

  protected readonly result = toSignal(
    merge(toObservable(this.filters), this.reload$.pipe(map(() => this.filters()))).pipe(
      switchMap((f) =>
        this.api.posts(f).pipe(
          map((r) => ({ loading: false, data: r as ListResult | null, error: null as string | null })),
          catchError((e) => of({ loading: false, data: null, error: errorMessage(e) })),
          startWith({ loading: true, data: null as ListResult | null, error: null as string | null }),
        ),
      ),
    ),
    { initialValue: { loading: true, data: null, error: null } },
  );

  // Keep the last counts while a new page loads, so the tabs don't flicker.
  private lastCounts: Record<string, number> = {};
  protected readonly counts = computed(() => {
    const counts = this.result().data?.counts;
    if (counts) this.lastCounts = counts;
    return this.lastCounts;
  });

  protected count(status: string) {
    const c = this.counts();
    if (status === 'all') {
      return Object.entries(c)
        .filter(([s]) => s !== 'trash' && s !== 'auto-draft')
        .reduce((sum, [, n]) => sum + n, 0);
    }
    return c[status] ?? 0;
  }

  protected navigate(params: Record<string, string | number | null>) {
    this.router.navigate([], { queryParams: { ...params, pagina: params['pagina'] ?? null }, queryParamsHandling: 'merge' });
  }

  protected async trash(post: Post) {
    const ok = await this.confirm.ask({
      title: '¿Mover a la papelera?',
      message: `«${post.title}» dejará de verse en el sitio. Podrás restaurarla desde la papelera.`,
      confirmText: 'Mover a la papelera',
      danger: true,
    });
    if (ok) this.run(this.api.trashPost(post.id), 'Publicación movida a la papelera.');
  }

  protected restore(post: Post) {
    this.run(this.api.restorePost(post.id), 'Publicación restaurada.');
  }

  protected async destroy(post: Post) {
    const ok = await this.confirm.ask({
      title: '¿Eliminar definitivamente?',
      message: `«${post.title}» se borrará para siempre de la base de datos. Esta acción no se puede deshacer.`,
      confirmText: 'Eliminar para siempre',
      danger: true,
    });
    if (ok) this.run(this.api.deletePost(post.id), 'Publicación eliminada definitivamente.');
  }

  private run(request: Observable<unknown>, success: string) {
    request.subscribe({
      next: () => {
        this.toast.success(success);
        this.reload$.next();
      },
      error: (e: unknown) => this.toast.error(errorMessage(e)),
    });
  }
}
