import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { AdminApiService } from '../../core/admin-api.service';
import { AuthService } from '../../core/auth.service';
import { Icon } from '../../shared/icon';
import { ToastService } from '../../shared/toast.service';
import { avatarColor, initials } from '../shared/avatar';
import { FieldErrors, errorMessage, fieldErrors } from '../shared/errors';

const PERMISSION_LABELS: Record<string, string> = {
  'publicaciones.crear': 'Crear publicaciones',
  'publicaciones.ver_todas': 'Editar publicaciones de otros',
  'publicaciones.publicar': 'Publicar sin revisión',
  'publicaciones.eliminar': 'Mover a la papelera',
  'publicaciones.eliminar_definitivo': 'Eliminar definitivamente',
  'categorias.gestionar': 'Gestionar categorías',
  'medios.subir': 'Subir archivos',
  'mensajes.gestionar': 'Gestionar mensajes',
  'usuarios.gestionar': 'Gestionar usuarios',
  'roles.gestionar': 'Gestionar roles',
  'actividad.ver': 'Ver historial',
};

@Component({
  selector: 'app-profile',
  imports: [Icon, DatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (auth.user(); as u) {
      <section class="hero">
        <span class="a-avatar big" [style.background]="color()">{{ letters() }}</span>
        <div class="hero-text">
          <h1>{{ u.name }}</h1>
          <p>{{ '@' + u.username }} · {{ u.email }}</p>
          <div class="chips">
            <span class="chip"><app-icon name="key" [size]="14" /> {{ u.role_label }}</span>
            @if (u.registered_at) {
              <span class="chip"><app-icon name="calendar" [size]="14" /> Desde {{ u.registered_at | date: 'MMMM y' }}</span>
            }
          </div>
        </div>
      </section>

      <div class="layout">
        <form class="a-card" (submit)="$event.preventDefault(); save()">
          <h2><app-icon name="user" [size]="18" /> Datos personales</h2>
          <div class="a-grid-2">
            <div class="field">
              <label for="pr-name">Nombre visible</label>
              <input id="pr-name" [value]="name()" (input)="name.set($any($event.target).value)" />
              @if (errors()['name']) { <span class="error">{{ errors()['name'] }}</span> }
            </div>
            <div class="field">
              <label for="pr-email">Correo electrónico</label>
              <input id="pr-email" type="email" [value]="email()" (input)="email.set($any($event.target).value)" />
              @if (errors()['email']) { <span class="error">{{ errors()['email'] }}</span> }
            </div>
          </div>

          <h2 class="mt"><app-icon name="lock" [size]="18" /> Cambiar contraseña</h2>
          <div class="field">
            <label for="pr-current">Contraseña actual</label>
            <input id="pr-current" type="password" [value]="current()" (input)="current.set($any($event.target).value)" autocomplete="current-password" />
            @if (errors()['current_password']) { <span class="error">{{ errors()['current_password'] }}</span> }
          </div>
          <div class="a-grid-2">
            <div class="field">
              <label for="pr-pass">Nueva contraseña</label>
              <input id="pr-pass" type="password" [value]="password()" (input)="password.set($any($event.target).value)" autocomplete="new-password" />
              @if (password()) {
                <span class="strength" [attr.data-level]="strength()"><i></i><i></i><i></i><i></i> {{ strengthLabel() }}</span>
              }
              @if (errors()['password']) { <span class="error">{{ errors()['password'] }}</span> }
            </div>
            <div class="field">
              <label for="pr-pass2">Repetir nueva contraseña</label>
              <input id="pr-pass2" type="password" [value]="confirmation()" (input)="confirmation.set($any($event.target).value)" autocomplete="new-password" />
            </div>
          </div>
          
          <button type="submit" class="btn" [disabled]="saving()">{{ saving() ? 'Guardando…' : 'Guardar cambios' }}</button>
        </form>

        <aside class="a-card">
          <h2><app-icon name="key" [size]="18" /> Tus permisos</h2>
          <ul class="perms">
            @for (p of permissions(); track p) {
              <li><app-icon name="check" [size]="14" [stroke]="2.4" /> {{ p }}</li>
            } @empty {
              <li class="none">Sin permisos asignados.</li>
            }
          </ul>
          <p class="hint">Los permisos dependen de tu rol. Un administrador puede cambiarlos en “Roles y permisos”.</p>
        </aside>
      </div>
    }
  `,
  styles: `
    .hero {
      display: flex;
      align-items: center;
      gap: 1.25rem;
      margin-bottom: 1.5rem;
      padding: 1.75rem 2rem;
      border-radius: 20px;
      background: linear-gradient(120deg, #03241a, var(--c-primary-dark) 60%, var(--c-primary));
      color: #cfe5dd;
      box-shadow: 0 20px 50px rgba(1, 17, 12, 0.15);
      h1 { margin: 0; font: 700 1.6rem var(--f-body); text-transform: none; color: #fff; }
      p { margin: 0.2rem 0 0.75rem; }
    }
    .a-avatar.big { width: 76px; height: 76px; font-size: 1.5rem; box-shadow: 0 0 0 4px rgba(255, 255, 255, 0.2); }
    .chips { display: flex; gap: 0.5rem; flex-wrap: wrap; }
    .chip { display: inline-flex; align-items: center; gap: 0.35rem; padding: 0.3rem 0.7rem; border-radius: 999px; background: rgba(255, 255, 255, 0.12); color: #fff; font-size: 0.8rem; font-weight: 600; text-transform: capitalize; }
    .layout { display: grid; grid-template-columns: 1fr 320px; gap: 1.25rem; align-items: start; @media (max-width: 1000px) { grid-template-columns: 1fr; } }
    .mt { margin-top: 1.5rem; padding-top: 1.25rem; border-top: 1px solid #edf1f0; }
    .hint { display: flex; align-items: center; gap: 0.4rem; font-size: 0.82rem; color: #8a918f; app-icon { color: var(--c-primary); } }
    .perms { list-style: none; margin: 0 0 1rem; padding: 0; display: grid; gap: 0.45rem; }
    .perms li { display: flex; align-items: center; gap: 0.5rem; font-size: 0.9rem; color: var(--c-heading); }
    .perms app-icon { display: grid; place-items: center; width: 22px; height: 22px; border-radius: 50%; background: var(--c-soft); color: var(--c-primary); }
    .perms .none { color: #8a918f; }
    .strength {
      display: flex;
      align-items: center;
      gap: 4px;
      font-size: 0.78rem;
      color: #8a918f;
      i { width: 28px; height: 4px; border-radius: 2px; background: #e3e9e7; }
      &[data-level='1'] i:nth-child(-n + 1) { background: var(--c-danger); }
      &[data-level='2'] i:nth-child(-n + 2) { background: #f0a43a; }
      &[data-level='3'] i:nth-child(-n + 3) { background: #6bbf9f; }
      &[data-level='4'] i:nth-child(-n + 4) { background: var(--c-primary); }
    }
  `,
})
export class Profile {
  private api = inject(AdminApiService);
  private toast = inject(ToastService);
  protected readonly auth = inject(AuthService);

  protected readonly name = signal(this.auth.user()?.name ?? '');
  protected readonly email = signal(this.auth.user()?.email ?? '');
  protected readonly current = signal('');
  protected readonly password = signal('');
  protected readonly confirmation = signal('');
  protected readonly saving = signal(false);
  protected readonly errors = signal<FieldErrors>({});

  protected readonly color = computed(() => avatarColor(this.auth.user()?.id ?? 0));
  protected readonly letters = computed(() => initials(this.auth.user()?.name));
  protected readonly permissions = computed(() => (this.auth.user()?.permissions ?? []).map((p) => PERMISSION_LABELS[p] ?? p));

  protected readonly strength = computed(() => {
    const p = this.password();
    let score = 0;
    if (p.length >= 8) score++;
    if (p.length >= 12) score++;
    if (/[A-Z]/.test(p) && /[a-z]/.test(p)) score++;
    if (/\d/.test(p) && /[^A-Za-z0-9]/.test(p)) score++;
    return Math.max(1, score);
  });
  protected readonly strengthLabel = computed(() => ['', 'Débil', 'Regular', 'Buena', 'Muy segura'][this.strength()]);

  protected save() {
    if (this.password() && this.password() !== this.confirmation()) {
      this.errors.set({ password: 'Las contraseñas no coinciden.' });
      return;
    }

    const data: Record<string, unknown> = { name: this.name().trim(), email: this.email().trim() };
    if (this.password()) {
      data['current_password'] = this.current();
      data['password'] = this.password();
      data['password_confirmation'] = this.confirmation();
    }

    this.saving.set(true);
    this.errors.set({});
    this.api.updateProfile(data).subscribe({
      next: ({ data: user }) => {
        this.saving.set(false);
        this.auth.user.set(user);
        this.current.set('');
        this.password.set('');
        this.confirmation.set('');
        this.toast.success('Perfil actualizado.');
      },
      error: (e) => {
        this.saving.set(false);
        this.errors.set(fieldErrors(e));
        this.toast.error(errorMessage(e, 'No se pudo guardar.'));
      },
    });
  }
}
