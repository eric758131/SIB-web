import { ChangeDetectionStrategy, Component, computed, input, signal } from '@angular/core';

interface MonthPoint {
  month: string;
  label: string;
  total: number;
}

/**
 * Column chart of published posts per month (single series, brand green).
 * Columns <= 24px with a 4px rounded top, hairline recessive grid, hover tooltip and
 * an accessible table alternative.
 */
@Component({
  selector: 'app-posts-chart',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="chart" (mouseleave)="hover.set(null)">
      <svg [attr.viewBox]="'0 0 ' + W + ' ' + H" preserveAspectRatio="none" role="img" [attr.aria-label]="summary()">
        @for (t of ticks(); track t) {
          <line class="grid" [attr.x1]="PAD_L" [attr.x2]="W - PAD_R" [attr.y1]="y(t)" [attr.y2]="y(t)" />
          <text class="tick" [attr.x]="PAD_L - 8" [attr.y]="y(t) + 4" text-anchor="end">{{ t }}</text>
        }

        @for (p of data(); track p.month; let i = $index) {
          <!-- Hit target wider than the mark -->
          <rect class="hit" [attr.x]="slotX(i)" [attr.y]="PAD_T" [attr.width]="slot()" [attr.height]="plotH" (mouseenter)="hover.set(i)" />
          @if (p.total > 0) {
            <path class="bar" [class.dim]="hover() !== null && hover() !== i" [attr.d]="barPath(i, p.total)" />
          }
          <text class="label" [attr.x]="slotX(i) + slot() / 2" [attr.y]="H - 6" text-anchor="middle">{{ p.label }}</text>
          @if (p.total === max() && p.total > 0) {
            <text class="value" [attr.x]="slotX(i) + slot() / 2" [attr.y]="y(p.total) - 7" text-anchor="middle">{{ p.total }}</text>
          }
        }
      </svg>

      @if (hover() !== null) {
        @let p = data()[hover()!];
        <div class="tooltip" [style.left.%]="((slotX(hover()!) + slot() / 2) / W) * 100">
          <strong>{{ p.total }} {{ p.total === 1 ? 'publicación' : 'publicaciones' }}</strong>
          <span>{{ monthName(p.month) }}</span>
        </div>
      }
    </div>

    <table class="sr-only">
      <caption>Publicaciones por mes</caption>
      <thead><tr><th>Mes</th><th>Publicaciones</th></tr></thead>
      <tbody>
        @for (p of data(); track p.month) {
          <tr><td>{{ monthName(p.month) }}</td><td>{{ p.total }}</td></tr>
        }
      </tbody>
    </table>
  `,
  styles: `
    :host { display: block; }
    .chart { position: relative; }
    svg { display: block; width: 100%; height: 230px; overflow: visible; }
    .grid { stroke: #edf1f0; stroke-width: 1; vector-effect: non-scaling-stroke; }
    .tick, .label { fill: #8a918f; font: 500 11px var(--f-body); }
    .value { fill: var(--c-heading); font: 700 12px var(--f-body); }
    .bar { fill: var(--c-primary); transition: opacity 0.2s; }
    .bar.dim { opacity: 0.35; }
    .hit { fill: transparent; cursor: default; }
    .tooltip {
      position: absolute;
      top: 0;
      transform: translate(-50%, -8px);
      display: flex;
      flex-direction: column;
      padding: 0.45rem 0.7rem;
      background: var(--c-dark);
      color: #fff;
      border-radius: 8px;
      font-size: 0.8rem;
      white-space: nowrap;
      pointer-events: none;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
      strong { font-size: 0.85rem; }
      span { color: #a9c2b9; text-transform: capitalize; }
    }
  `,
})
export class PostsChart {
  readonly data = input.required<MonthPoint[]>();

  protected readonly hover = signal<number | null>(null);

  protected readonly W = 640;
  protected readonly H = 230;
  protected readonly PAD_L = 30;
  protected readonly PAD_R = 6;
  protected readonly PAD_T = 22;
  private readonly PAD_B = 26;
  protected readonly plotH = this.H - this.PAD_T - this.PAD_B;

  protected readonly max = computed(() => Math.max(0, ...this.data().map((d) => d.total)));

  /** Clean axis maximum and 3-4 round ticks. */
  private readonly axisMax = computed(() => {
    const m = Math.max(this.max(), 4);
    const step = Math.ceil(m / 4);
    return step * 4;
  });

  protected readonly ticks = computed(() => {
    const step = this.axisMax() / 4;
    return [0, step, step * 2, step * 3, step * 4];
  });

  protected readonly slot = computed(() => (this.W - this.PAD_L - this.PAD_R) / Math.max(this.data().length, 1));

  protected readonly summary = computed(() => {
    const total = this.data().reduce((s, d) => s + d.total, 0);
    return `Publicaciones por mes en los últimos 12 meses: ${total} en total.`;
  });

  protected y(value: number) {
    return this.PAD_T + this.plotH - (value / this.axisMax()) * this.plotH;
  }

  protected slotX(i: number) {
    return this.PAD_L + i * this.slot();
  }

  /** Column with a 4px rounded data-end, square at the baseline. */
  protected barPath(i: number, value: number) {
    const w = Math.min(24, this.slot() - 2);
    const x = this.slotX(i) + (this.slot() - w) / 2;
    const top = this.y(value);
    const base = this.y(0);
    const r = Math.min(4, (base - top) / 2, w / 2);
    return `M${x},${base} V${top + r} Q${x},${top} ${x + r},${top} H${x + w - r} Q${x + w},${top} ${x + w},${top + r} V${base} Z`;
  }

  protected monthName(ym: string) {
    const [y, m] = ym.split('-').map(Number);
    return new Date(y, m - 1, 1).toLocaleDateString('es-BO', { month: 'long', year: 'numeric' });
  }
}
