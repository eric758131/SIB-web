import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AdminApiService } from '../../core/admin-api.service';
import { AuthService } from '../../core/auth.service';
import { Dashboard as DashboardData } from '../../core/models';
import { Icon } from '../../shared/icon';
import { ActivityFeed } from '../shared/activity-feed';
import { STATUS_LABELS, errorMessage } from '../shared/errors';
import { PostsChart } from './posts-chart';

@Component({
  selector: 'app-dashboard',
  imports: [RouterLink, DatePipe, Icon, PostsChart, ActivityFeed],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.scss',
})
export class Dashboard {
  protected readonly auth = inject(AuthService);
  protected readonly data = signal<DashboardData | null>(null);
  protected readonly error = signal<string | null>(null);
  protected readonly statusLabels = STATUS_LABELS;

  protected readonly greeting = (() => {
    const h = new Date().getHours();
    return h < 12 ? 'Buenos días' : h < 19 ? 'Buenas tardes' : 'Buenas noches';
  })();
  protected readonly today = new Date();

  protected readonly firstName = computed(() => (this.auth.user()?.name ?? '').split(/\s+/)[0]);
  protected readonly yearTotal = computed(() => this.data()?.posts_per_month.reduce((s, m) => s + m.total, 0) ?? 0);

  constructor() {
    inject(AdminApiService)
      .dashboard()
      .subscribe({
        next: (d) => this.data.set(d),
        error: (e) => this.error.set(errorMessage(e)),
      });
  }
}
