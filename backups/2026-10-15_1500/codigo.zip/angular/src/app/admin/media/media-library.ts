import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { EMPTY, catchError, concatMap, finalize, from, tap } from 'rxjs';
import { AdminApiService } from '../../core/admin-api.service';
import { AuthService } from '../../core/auth.service';
import { Media } from '../../core/models';
import { Icon } from '../../shared/icon';
import { ToastService } from '../../shared/toast.service';
import { errorMessage } from '../shared/errors';

@Component({
  selector: 'app-media-library',
  imports: [DatePipe, Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="a-page-header">
      <div>
        <h1>Medios</h1>
        <p>Imágenes y documentos del sitio. Súbelos aquí para usarlos en las publicaciones.</p>
      </div>
    </div>

    @if (auth.can('medios.subir')) {
      <label
        class="dropzone"
        [class.is-over]="dragOver()"
        [class.is-busy]="uploading() > 0"
        (dragover)="$event.preventDefault(); dragOver.set(true)"
        (dragleave)="dragOver.set(false)"
        (drop)="onDrop($event)"
      >
        <input type="file" multiple hidden accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx" (change)="onPick($event)" />
        <span class="dz-icon"><app-icon name="upload" [size]="26" [stroke]="1.6" /></span>
        @if (uploading() > 0) {
          <strong>Subiendo {{ uploading() }} {{ uploading() === 1 ? 'archivo' : 'archivos' }}…</strong>
        } @else {
          <strong>Arrastra archivos aquí o <u>haz clic para elegir</u></strong>
        }
        <small>Imágenes, PDF, Word, Excel o PowerPoint · máximo 20 MB</small>
      </label>
    }

    <div class="toolbar-row">
      <div class="a-tabs">
        <button type="button" [class.is-active]="type === ''" (click)="type = ''; load(1)">Todos</button>
        <button type="button" [class.is-active]="type === 'image'" (click)="type = 'image'; load(1)">Imágenes</button>
      </div>
      <div class="a-toolbar">
        <form (submit)="$event.preventDefault(); query = q.value.trim(); load(1)">
          <app-icon name="search" [size]="17" class="search-icon" />
          <input #q type="search" class="input search-input" placeholder="Buscar por nombre…" aria-label="Buscar medios" />
        </form>
      </div>
    </div>

    @if (loading()) {
      <div class="grid">
        @for (i of [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]; track i) {
          <div class="skeleton" style="aspect-ratio: 1; border-radius: 14px"></div>
        }
      </div>
    } @else {
      <div class="grid">
        @for (m of items(); track m.id) {
          <figure class="item">
            <a [href]="m.url" target="_blank" rel="noopener" class="preview">
              @if (m.is_image) {
                <img [src]="m.url" [alt]="m.title" loading="lazy" />
              } @else {
                <span class="file"><app-icon name="file" [size]="38" [stroke]="1.3" /><em>{{ ext(m.url) }}</em></span>
              }
            </a>
            <button type="button" class="copy" [class.done]="copied() === m.id" (click)="copy(m)" [attr.aria-label]="'Copiar enlace de ' + m.title">
              <app-icon [name]="copied() === m.id ? 'check' : 'copy'" [size]="15" />
            </button>
            <figcaption>
              <strong [title]="m.title">{{ m.title }}</strong>
              <small>{{ m.uploaded_at | date: 'd MMM y' }}</small>
            </figcaption>
          </figure>
        } @empty {
          <div class="a-empty full">
            <span class="a-empty-icon"><app-icon name="image" [size]="28" [stroke]="1.5" /></span>
            <strong>No hay archivos</strong>
          </div>
        }
      </div>

      @if (lastPage() > 1) {
        <div class="a-pagination">
          <span>{{ total() }} archivos · página {{ page() }} de {{ lastPage() }}</span>
          <div>
            <button type="button" class="btn btn--outline btn--sm" [disabled]="page() <= 1" (click)="load(page() - 1)">Anterior</button>
            <button type="button" class="btn btn--outline btn--sm" [disabled]="page() >= lastPage()" (click)="load(page() + 1)">Siguiente</button>
          </div>
        </div>
      }
    }
  `,
  styles: `
    code { font-size: 0.85em; padding: 0.1rem 0.35rem; border-radius: 5px; background: #e8efed; }
    .dropzone {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.35rem;
      margin-bottom: 1.25rem;
      padding: 1.75rem 1rem;
      border: 2px dashed #c8d8d2;
      border-radius: 18px;
      background: #fff;
      text-align: center;
      cursor: pointer;
      transition: border-color 0.2s, background 0.2s, transform 0.2s;
      strong { color: var(--c-heading); font-size: 0.98rem; u { color: var(--c-primary); text-underline-offset: 3px; } }
      small { color: #8a918f; font-size: 0.82rem; }
      &:hover, &.is-over { border-color: var(--c-primary); background: #f5fbf8; }
      &.is-over { transform: scale(1.01); }
      &.is-busy { pointer-events: none; opacity: 0.85; }
    }
    .dz-icon { display: grid; place-items: center; width: 56px; height: 56px; margin-bottom: 0.35rem; border-radius: 16px; background: var(--c-soft); color: var(--c-primary); }
    .is-busy .dz-icon { animation: pulse 1s ease-in-out infinite; }
    @keyframes pulse { 50% { transform: scale(1.08); } }
    .toolbar-row { display: flex; justify-content: space-between; gap: 0.75rem; flex-wrap: wrap; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(170px, 1fr)); gap: 1rem; }
    .full { grid-column: 1 / -1; }
    .item {
      position: relative;
      margin: 0;
      background: #fff;
      border-radius: 14px;
      overflow: hidden;
      box-shadow: 0 0 0 1px rgba(16, 40, 32, 0.07);
      transition: transform 0.2s, box-shadow 0.2s;
      &:hover { transform: translateY(-3px); box-shadow: 0 14px 30px rgba(16, 40, 32, 0.1), 0 0 0 1px rgba(37, 142, 111, 0.25); }
      &:hover .copy { opacity: 1; }
    }
    .preview { display: block; aspect-ratio: 4 / 3; background: linear-gradient(135deg, #eef4f2, #f8fbfa); }
    .preview img { width: 100%; height: 100%; object-fit: cover; }
    .file { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 0.4rem; height: 100%; color: var(--c-primary); em { font-style: normal; font-size: 0.72rem; font-weight: 800; letter-spacing: 0.08em; padding: 0.1rem 0.45rem; border-radius: 5px; background: var(--c-primary); color: #fff; } }
    .copy {
      position: absolute;
      top: 8px;
      right: 8px;
      display: grid;
      place-items: center;
      width: 32px;
      height: 32px;
      border: 0;
      border-radius: 9px;
      background: rgba(255, 255, 255, 0.95);
      color: var(--c-heading);
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
      cursor: pointer;
      opacity: 0;
      transition: opacity 0.2s, background 0.2s;
      &.done { opacity: 1; background: var(--c-primary); color: #fff; }
      @media (hover: none) { opacity: 1; }
    }
    figcaption { padding: 0.65rem 0.75rem; display: grid; gap: 0.1rem; }
    strong { font-size: 0.82rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; color: var(--c-heading); }
    small { font-size: 0.74rem; color: #8a918f; }
  `,
})
export class MediaLibrary implements OnInit {
  private api = inject(AdminApiService);
  private toast = inject(ToastService);
  protected readonly auth = inject(AuthService);

  protected readonly items = signal<Media[]>([]);
  protected readonly loading = signal(true);
  protected readonly uploading = signal(0);
  protected readonly dragOver = signal(false);
  protected readonly page = signal(1);
  protected readonly lastPage = signal(1);
  protected readonly total = signal(0);
  protected readonly copied = signal<number | null>(null);
  protected query = '';
  protected type = '';

  ngOnInit() {
    this.load(1);
  }

  protected load(page: number) {
    this.loading.set(true);
    this.api.media({ q: this.query, type: this.type, page }).subscribe({
      next: (res) => {
        this.items.set(res.data);
        this.page.set(res.meta.current_page);
        this.lastPage.set(res.meta.last_page);
        this.total.set(res.meta.total);
        this.loading.set(false);
      },
      error: (e) => {
        this.toast.error(errorMessage(e));
        this.loading.set(false);
      },
    });
  }

  protected onPick(event: Event) {
    const input = event.target as HTMLInputElement;
    this.uploadFiles(Array.from(input.files ?? []));
    input.value = '';
  }

  protected onDrop(event: DragEvent) {
    event.preventDefault();
    this.dragOver.set(false);
    this.uploadFiles(Array.from(event.dataTransfer?.files ?? []));
  }

  /** Upload one file at a time so the counter goes down as each one finishes. */
  private uploadFiles(files: File[]) {
    if (!files.length) return;

    let ok = 0;
    this.uploading.set(files.length);

    from(files)
      .pipe(
        concatMap((file) =>
          this.api.upload(file).pipe(
            tap(() => ok++),
            catchError((e) => {
              this.toast.error(`${file.name}: ${errorMessage(e, 'no se pudo subir.')}`);
              return EMPTY;
            }),
            finalize(() => this.uploading.update((n) => n - 1)),
          ),
        ),
      )
      .subscribe({
        complete: () => {
          if (ok) this.toast.success(ok === 1 ? 'Archivo subido correctamente.' : `${ok} archivos subidos correctamente.`);
          this.load(1);
        },
      });
  }

  protected ext(url: string) {
    return (url.split('.').pop() ?? '').slice(0, 4).toUpperCase();
  }

  protected copy(media: Media) {
    navigator.clipboard?.writeText(media.url).then(() => {
      this.copied.set(media.id);
      this.toast.success('Enlace copiado al portapapeles.');
      setTimeout(() => this.copied.set(null), 1500);
    });
  }
}
