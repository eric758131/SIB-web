import { ChangeDetectionStrategy, Component, OnInit, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AdminApiService } from '../../core/admin-api.service';
import { Category } from '../../core/models';
import { ConfirmService } from '../../shared/confirm.service';
import { Icon } from '../../shared/icon';
import { ToastService } from '../../shared/toast.service';
import { FieldErrors, errorMessage, fieldErrors } from '../shared/errors';

@Component({
  selector: 'app-categories',
  imports: [RouterLink, Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="a-page-header">
      <div>
        <h1>Categorías</h1>
        <p>Categorías usadas para agrupar las noticias.</p>
      </div>
    </div>

    <div class="layout">
      <form class="a-card form-card" (submit)="$event.preventDefault(); save()">
        <h2><app-icon [name]="editing() ? 'edit' : 'plus'" [size]="18" /> {{ editing() ? 'Editar categoría' : 'Nueva categoría' }}</h2>
        <div class="field">
          <label for="c-name">Nombre</label>
          <input id="c-name" [value]="name()" (input)="name.set($any($event.target).value)" placeholder="Ej.: Convenios" />
          @if (errors()['name']) { <span class="error">{{ errors()['name'] }}</span> }
        </div>
        <div class="field">
          <label for="c-slug">Slug <span class="hint">(opcional)</span></label>
          <input id="c-slug" [value]="slug()" (input)="slug.set($any($event.target).value)" placeholder="Se genera a partir del nombre" />
        </div>
        <div class="field">
          <label for="c-desc">Descripción</label>
          <textarea id="c-desc" rows="3" [value]="description()" (input)="description.set($any($event.target).value)"></textarea>
        </div>
        <div class="buttons">
          <button type="submit" class="btn" [disabled]="saving()">{{ editing() ? 'Guardar cambios' : 'Añadir categoría' }}</button>
          @if (editing()) {
            <button type="button" class="btn btn--ghost" (click)="reset()">Cancelar</button>
          }
        </div>
      </form>

      <div class="list">
        @if (loading()) {
          @for (i of [1, 2, 3]; track i) {
            <div class="skeleton" style="height: 74px; border-radius: 14px"></div>
          }
        }
        @for (c of items(); track c.id) {
          <div class="cat" [class.is-editing]="editing()?.id === c.id">
            <span class="cat-icon"><app-icon name="tag" [size]="18" /></span>
            <div class="cat-body">
              <strong>
                {{ c.name }}
                @if (c.is_default) { <span class="a-badge plain">Por defecto</span> }
              </strong>
              <small>/{{ c.slug }}{{ c.description ? ' · ' + c.description : '' }}</small>
            </div>
            <a class="count" routerLink="/admin/publicaciones" [queryParams]="{ categoria: c.id }" title="Ver publicaciones">
              <strong>{{ c.count }}</strong><small>{{ c.count === 1 ? 'publicación' : 'publicaciones' }}</small>
            </a>
            <div class="actions">
              <button type="button" class="a-icon-btn" title="Editar" aria-label="Editar" (click)="edit(c)"><app-icon name="edit" [size]="17" /></button>
              <button type="button" class="a-icon-btn danger" title="Eliminar" aria-label="Eliminar" [disabled]="c.is_default" (click)="remove(c)"><app-icon name="trash" [size]="17" /></button>
            </div>
          </div>
        } @empty {
          @if (!loading()) {
            <div class="a-empty"><strong>No hay categorías.</strong></div>
          }
        }
        @if (total()) {
          <p class="total">{{ items().length }} categorías · {{ total() }} publicaciones clasificadas</p>
        }
      </div>
    </div>
  `,
  styles: `
    .layout { display: grid; grid-template-columns: 360px 1fr; gap: 1.25rem; align-items: start; @media (max-width: 900px) { grid-template-columns: 1fr; } }
    .form-card { position: sticky; top: 80px; @media (max-width: 900px) { position: static; } }
    .buttons { display: flex; gap: 0.5rem; }
    .hint { font-weight: 400; color: #8a918f; font-size: 0.8rem; }
    .list { display: grid; gap: 0.6rem; }
    .cat {
      display: flex;
      align-items: center;
      gap: 1rem;
      padding: 0.95rem 1.1rem;
      background: #fff;
      border-radius: 14px;
      box-shadow: 0 0 0 1px rgba(16, 40, 32, 0.07);
      transition: box-shadow 0.2s;
      &:hover { box-shadow: 0 10px 26px rgba(16, 40, 32, 0.08), 0 0 0 1px rgba(37, 142, 111, 0.25); }
      &.is-editing { box-shadow: 0 0 0 2px var(--c-primary); }
    }
    .cat-icon { display: grid; place-items: center; width: 42px; height: 42px; border-radius: 12px; background: var(--c-soft); color: var(--c-primary); flex-shrink: 0; }
    .cat-body { flex: 1; min-width: 0; strong { display: flex; align-items: center; gap: 0.5rem; color: var(--c-heading); } small { display: block; color: #8a918f; font-size: 0.82rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; } }
    .count { display: flex; flex-direction: column; align-items: center; min-width: 90px; padding: 0.35rem 0.6rem; border-radius: 10px; background: #f6faf8; color: var(--c-heading); strong { font-size: 1.15rem; line-height: 1.1; } small { font-size: 0.72rem; color: #8a918f; } &:hover { background: var(--c-soft); color: var(--c-primary); } }
    .actions { display: flex; gap: 0.1rem; }
    .total { margin: 0.25rem 0 0; font-size: 0.85rem; color: #8a918f; text-align: right; }
  `,
})
export class Categories implements OnInit {
  private api = inject(AdminApiService);
  private toast = inject(ToastService);
  private confirm = inject(ConfirmService);

  protected readonly items = signal<Category[]>([]);
  protected readonly loading = signal(true);
  protected readonly saving = signal(false);
  protected readonly editing = signal<Category | null>(null);
  protected readonly errors = signal<FieldErrors>({});

  protected readonly name = signal('');
  protected readonly slug = signal('');
  protected readonly description = signal('');

  protected readonly total = computed(() => this.items().reduce((s, c) => s + c.count, 0));

  ngOnInit() {
    this.load();
  }

  private load() {
    this.api.categories().subscribe({
      next: (c) => {
        this.items.set(c);
        this.loading.set(false);
      },
      error: (e) => {
        this.loading.set(false);
        this.toast.error(errorMessage(e));
      },
    });
  }

  protected edit(c: Category) {
    this.editing.set(c);
    this.name.set(c.name);
    this.slug.set(c.slug);
    this.description.set(c.description ?? '');
    this.errors.set({});
  }

  protected reset() {
    this.editing.set(null);
    this.name.set('');
    this.slug.set('');
    this.description.set('');
    this.errors.set({});
  }

  protected save() {
    if (!this.name().trim()) {
      this.errors.set({ name: 'El nombre es obligatorio.' });
      return;
    }

    const data = { name: this.name().trim(), slug: this.slug().trim(), description: this.description().trim() };
    const editing = this.editing();
    this.saving.set(true);

    (editing ? this.api.updateCategory(editing.id, data) : this.api.createCategory(data)).subscribe({
      next: () => {
        this.saving.set(false);
        this.toast.success(editing ? 'Categoría actualizada.' : 'Categoría creada.');
        this.reset();
        this.load();
      },
      error: (e) => {
        this.saving.set(false);
        this.errors.set(fieldErrors(e));
        this.toast.error(errorMessage(e));
      },
    });
  }

  protected async remove(c: Category) {
    const ok = await this.confirm.ask({
      title: `¿Eliminar «${c.name}»?`,
      message: 'Sus publicaciones pasarán a la categoría por defecto.',
      confirmText: 'Eliminar categoría',
      danger: true,
    });
    if (!ok) return;

    this.api.deleteCategory(c.id).subscribe({
      next: () => {
        this.toast.success('Categoría eliminada.');
        if (this.editing()?.id === c.id) this.reset();
        this.load();
      },
      error: (e) => this.toast.error(errorMessage(e)),
    });
  }
}
