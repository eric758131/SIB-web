const AVATAR_COLORS = ['#258e6f', '#1d6fa5', '#7a4fb3', '#b5653a', '#2f8f9d', '#a3446b', '#5b7a2e', '#4a5bbf'];

/** Stable background color for a user's initials (decorative only; the name is always shown). */
export function avatarColor(seed: string | number): string {
  const text = String(seed);
  let hash = 0;
  for (let i = 0; i < text.length; i++) hash = (hash * 31 + text.charCodeAt(i)) >>> 0;
  return AVATAR_COLORS[hash % AVATAR_COLORS.length];
}

export function initials(name: string | null | undefined): string {
  return (name ?? '?')
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? '')
    .join('');
}
