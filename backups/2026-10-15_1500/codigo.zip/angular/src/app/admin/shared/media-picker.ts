import { ChangeDetectionStrategy, Component, OnInit, inject, input, output, signal } from '@angular/core';
import { AdminApiService } from '../../core/admin-api.service';
import { Media } from '../../core/models';
import { Icon } from '../../shared/icon';
import { errorMessage } from './errors';

/** Modal to pick an existing file from the media library or upload a new one. */
@Component({
  selector: 'app-media-picker',
  imports: [Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="a-modal-backdrop" (click)="closed.emit()">
      <div class="a-modal a-modal--wide" role="dialog" aria-modal="true" aria-labelledby="media-title" (click)="$event.stopPropagation()">
        <header>
          <h2 id="media-title">{{ title() }}</h2>
          <button type="button" class="a-icon-btn" aria-label="Cerrar" (click)="closed.emit()"><app-icon name="close" /></button>
        </header>

        <div class="body">
          <div class="a-toolbar">
            <label class="btn btn--sm upload">
              <app-icon name="upload" [size]="16" /> {{ uploading() ? 'Subiendo…' : 'Subir archivo' }}
              <input type="file" [accept]="imagesOnly() ? 'image/*' : 'image/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx'" (change)="upload($event)" [disabled]="uploading()" hidden />
            </label>
            <form (submit)="$event.preventDefault(); search(q.value)">
              <input #q type="search" class="input" placeholder="Buscar en medios…" aria-label="Buscar en medios" />
            </form>
          </div>

          @if (error()) {
            <div class="alert alert--error">{{ error() }}</div>
          }

          @if (loading()) {
            <div class="spinner"></div>
          } @else {
            <div class="grid">
              @for (m of items(); track m.id) {
                <button type="button" class="item" [title]="m.title" (click)="selected.emit(m)">
                  @if (m.is_image) {
                    <img [src]="m.url" [alt]="m.title" loading="lazy" />
                  } @else {
                    <span class="file"><app-icon name="file" [size]="32" /> {{ m.title }}</span>
                  }
                </button>
              } @empty {
                <p class="a-empty">No hay archivos.</p>
              }
            </div>

            @if (lastPage() > 1) {
              <div class="a-pagination">
                <span>Página {{ page() }} de {{ lastPage() }}</span>
                <div>
                  <button type="button" class="btn btn--outline btn--sm" [disabled]="page() <= 1" (click)="load(page() - 1)">Anterior</button>
                  <button type="button" class="btn btn--outline btn--sm" [disabled]="page() >= lastPage()" (click)="load(page() + 1)">Siguiente</button>
                </div>
              </div>
            }
          }
        </div>
      </div>
    </div>
  `,
  styles: `
    .upload { cursor: pointer; }
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 0.6rem; }
    .item {
      aspect-ratio: 1;
      padding: 0;
      border: 2px solid transparent;
      border-radius: 6px;
      overflow: hidden;
      background: var(--c-soft);
      cursor: pointer;
      &:hover, &:focus-visible { border-color: var(--c-primary); }
      img { width: 100%; height: 100%; object-fit: cover; }
    }
    .file { display: flex; flex-direction: column; align-items: center; gap: 0.4rem; padding: 0.5rem; font-size: 0.75rem; color: var(--c-heading); word-break: break-word; }
  `,
})
export class MediaPicker implements OnInit {
  private api = inject(AdminApiService);

  readonly title = input('Seleccionar imagen');
  readonly imagesOnly = input(true);
  readonly selected = output<Media>();
  readonly closed = output<void>();

  protected readonly items = signal<Media[]>([]);
  protected readonly loading = signal(true);
  protected readonly uploading = signal(false);
  protected readonly error = signal<string | null>(null);
  protected readonly page = signal(1);
  protected readonly lastPage = signal(1);
  private query = '';

  ngOnInit() {
    this.load(1);
  }

  protected search(q: string) {
    this.query = q.trim();
    this.load(1);
  }

  protected load(page: number) {
    this.loading.set(true);
    this.api.media({ type: this.imagesOnly() ? 'image' : undefined, q: this.query, page }).subscribe({
      next: (res) => {
        this.items.set(res.data);
        this.page.set(res.meta.current_page);
        this.lastPage.set(res.meta.last_page);
        this.loading.set(false);
      },
      error: (e) => {
        this.error.set(errorMessage(e));
        this.loading.set(false);
      },
    });
  }

  protected upload(event: Event) {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (!file) return;

    this.uploading.set(true);
    this.error.set(null);
    this.api.upload(file).subscribe({
      next: (media) => {
        this.uploading.set(false);
        this.selected.emit(media);
      },
      error: (e) => {
        this.uploading.set(false);
        this.error.set(errorMessage(e, 'No se pudo subir el archivo.'));
      },
    });
  }
}
