import { HttpErrorResponse } from '@angular/common/http';

export type FieldErrors = Record<string, string>;

/** First validation message per field from a Laravel 422 response. */
export function fieldErrors(error: unknown): FieldErrors {
  if (error instanceof HttpErrorResponse && error.status === 422 && error.error?.errors) {
    const out: FieldErrors = {};
    for (const [field, messages] of Object.entries(error.error.errors as Record<string, string[]>)) {
      out[field] = messages[0];
    }
    return out;
  }
  return {};
}

/** Human readable message for any API error. */
export function errorMessage(error: unknown, fallback = 'Ocurrió un error. Inténtalo nuevamente.'): string {
  if (error instanceof HttpErrorResponse) {
    if (error.status === 0) return 'No se pudo conectar con el servidor. ¿Está encendido Laravel?';
    const errors = fieldErrors(error);
    const first = Object.values(errors)[0];
    if (first) return first;
    if (typeof error.error?.message === 'string' && error.error.message) return error.error.message;
  }
  return fallback;
}

export const STATUS_LABELS: Record<string, string> = {
  publish: 'Publicada',
  draft: 'Borrador',
  pending: 'Pendiente',
  future: 'Programada',
  private: 'Privada',
  trash: 'Papelera',
};
