import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Activity } from '../../core/models';
import { Icon } from '../../shared/icon';
import { avatarColor, initials } from './avatar';

const EVENT_ICONS: Record<string, string> = {
  created: 'plus',
  updated: 'edit',
  status: 'check',
  trashed: 'trash',
  deleted: 'trash',
  restored: 'restore',
  login: 'lock',
  read: 'eye',
  unread: 'inbox',
  trash: 'trash',
};

/** Timeline of activity log entries (spatie/laravel-activitylog). */
@Component({
  selector: 'app-activity-feed',
  imports: [DatePipe, Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <ol class="feed" [class.compact]="compact()">
      @for (a of items(); track a.id) {
        <li>
          <span class="a-avatar" [style.background]="color(a)">{{ letters(a) }}</span>
          <div class="body">
            <p>
              <strong>{{ a.causer?.name ?? 'Sistema' }}</strong> {{ a.description }}
            </p>
            <small>
              <span class="ev" [class]="'ev ev--' + (a.event ?? 'other')"><app-icon [name]="icon(a)" [size]="12" [stroke]="2.2" /></span>
              {{ a.created_at | date: 'd MMM y, HH:mm' }}
            </small>
          </div>
        </li>
      } @empty {
        <li class="empty">Todavía no hay actividad registrada.</li>
      }
    </ol>
  `,
  styles: `
    .feed { list-style: none; margin: 0; padding: 0; position: relative; }
    li { position: relative; display: flex; gap: 0.8rem; padding: 0.65rem 0; }
    li:not(:last-child)::before {
      content: '';
      position: absolute;
      left: 18px;
      top: 48px;
      bottom: -6px;
      width: 2px;
      background: #edf1f0;
    }
    .a-avatar { width: 38px; height: 38px; font-size: 0.78rem; }
    .body { min-width: 0; flex: 1; }
    p { margin: 0; font-size: 0.9rem; line-height: 1.45; color: #4a4f4e; strong { color: var(--c-heading); } }
    small { display: flex; align-items: center; gap: 0.4rem; margin-top: 0.25rem; font-size: 0.78rem; color: #8a918f; }
    .ev { display: inline-grid; place-items: center; width: 18px; height: 18px; border-radius: 50%; background: #eef2f1; color: #6b7270; }
    .ev--created, .ev--status, .ev--restored { background: #e3f4ed; color: #13684f; }
    .ev--trashed, .ev--deleted, .ev--trash { background: #fdecea; color: #8a2a1f; }
    .ev--updated { background: #e5efff; color: #1d4f9c; }
    .ev--login { background: #fff4de; color: #8a5a00; }
    .empty { color: #8a918f; font-size: 0.9rem; justify-content: center; padding: 1.5rem 0; }
    .compact li { padding: 0.5rem 0; }
  `,
})
export class ActivityFeed {
  readonly items = input.required<Activity[]>();
  readonly compact = input(false);

  protected icon(a: Activity) {
    return EVENT_ICONS[a.event ?? ''] ?? 'activity';
  }

  protected color(a: Activity) {
    return a.causer ? avatarColor(a.causer.id) : '#8a918f';
  }

  protected letters(a: Activity) {
    return a.causer ? initials(a.causer.name) : 'S';
  }
}
