import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  afterNextRender,
  effect,
  model,
  signal,
  untracked,
  viewChild,
} from '@angular/core';
import { Media } from '../../core/models';
import { Icon } from '../../shared/icon';
import { MediaPicker } from './media-picker';

const ALLOWED_TAGS = new Set([
  'P', 'H2', 'H3', 'H4', 'STRONG', 'B', 'EM', 'I', 'U', 'A', 'UL', 'OL', 'LI',
  'BLOCKQUOTE', 'BR', 'IMG', 'FIGURE', 'FIGCAPTION', 'TABLE', 'THEAD', 'TBODY', 'TR', 'TD', 'TH',
]);
const ALLOWED_ATTRS: Record<string, string[]> = { A: ['href', 'target', 'rel'], IMG: ['src', 'alt'] };

/**
 * Small WYSIWYG editor (contenteditable) that produces plain HTML.
 * Includes an HTML source mode.
 */
@Component({
  selector: 'app-rich-editor',
  imports: [Icon, MediaPicker],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './rich-editor.html',
  styleUrl: './rich-editor.scss',
})
export class RichEditor {
  readonly value = model('');

  protected readonly sourceMode = signal(false);
  protected readonly pickerOpen = signal(false);

  private readonly editor = viewChild<ElementRef<HTMLDivElement>>('editor');
  private lastEmitted: string | null = null;
  private savedRange: Range | null = null;

  constructor() {
    // Push external value changes (e.g. post loaded) into the editable area.
    effect(() => {
      const html = this.value();
      const el = this.editor()?.nativeElement;
      if (!el || untracked(this.sourceMode)) return;
      if (html !== this.lastEmitted) {
        el.innerHTML = html;
        this.lastEmitted = html;
      }
    });

    afterNextRender(() => {
      try {
        document.execCommand('defaultParagraphSeparator', false, 'p');
      } catch {
        // Not supported: the browser keeps its default.
      }
    });
  }

  protected onInput() {
    const el = this.editor()?.nativeElement;
    if (!el) return;
    this.lastEmitted = el.innerHTML;
    this.value.set(el.innerHTML);
  }

  protected exec(command: string, arg?: string) {
    this.editor()?.nativeElement.focus();
    document.execCommand(command, false, arg);
    this.onInput();
  }

  protected block(tag: string) {
    this.exec('formatBlock', `<${tag}>`);
  }

  protected link() {
    const url = prompt('Dirección del enlace (https://…):', 'https://');
    if (!url || url === 'https://') return;
    this.exec('createLink', url);
    // Open external links in a new tab.
    this.editor()
      ?.nativeElement.querySelectorAll(`a[href="${CSS.escape(url)}"]`)
      .forEach((a) => {
        if (/^https?:/.test(url)) {
          a.setAttribute('target', '_blank');
          a.setAttribute('rel', 'noopener');
        }
      });
    this.onInput();
  }

  protected openPicker() {
    const selection = window.getSelection();
    this.savedRange = selection && selection.rangeCount ? selection.getRangeAt(0).cloneRange() : null;
    this.pickerOpen.set(true);
  }

  protected insertImage(media: Media) {
    this.pickerOpen.set(false);
    const el = this.editor()?.nativeElement;
    if (!el) return;

    el.focus();
    const selection = window.getSelection();
    if (this.savedRange && el.contains(this.savedRange.commonAncestorContainer) && selection) {
      selection.removeAllRanges();
      selection.addRange(this.savedRange);
    }

    const html = media.is_image
      ? `<figure><img src="${media.url}" alt="${escapeAttr(media.title)}"></figure><p><br></p>`
      : `<p><a href="${media.url}" target="_blank" rel="noopener">${escapeHtml(media.title)}</a></p>`;
    document.execCommand('insertHTML', false, html);
    this.onInput();
  }

  protected toggleSource() {
    if (this.sourceMode()) {
      // Back to visual mode: the effect re-renders the editable area.
      this.lastEmitted = null;
      this.sourceMode.set(false);
      queueMicrotask(() => {
        const el = this.editor()?.nativeElement;
        if (el) {
          el.innerHTML = this.value();
          this.lastEmitted = this.value();
        }
      });
    } else {
      this.sourceMode.set(true);
    }
  }

  protected onSourceInput(event: Event) {
    this.value.set((event.target as HTMLTextAreaElement).value);
  }

  /** Clean pasted HTML (Word, Google Docs, other websites) down to simple tags. */
  protected onPaste(event: ClipboardEvent) {
    const html = event.clipboardData?.getData('text/html');
    if (!html) return;

    event.preventDefault();
    const doc = new DOMParser().parseFromString(html, 'text/html');
    clean(doc.body);
    document.execCommand('insertHTML', false, doc.body.innerHTML);
    this.onInput();
  }
}

function clean(node: Element) {
  for (const child of Array.from(node.children)) {
    clean(child);

    if (['SCRIPT', 'STYLE', 'META', 'LINK', 'IFRAME', 'OBJECT'].includes(child.tagName)) {
      child.remove();
      continue;
    }

    if (!ALLOWED_TAGS.has(child.tagName)) {
      // Unwrap: keep the text and children, drop the tag (span, font, div, h1...).
      const replacement = child.tagName === 'DIV' || child.tagName === 'H1' ? document.createElement('p') : null;
      if (replacement) {
        replacement.append(...Array.from(child.childNodes));
        child.replaceWith(replacement);
      } else {
        child.replaceWith(...Array.from(child.childNodes));
      }
      continue;
    }

    const allowed = ALLOWED_ATTRS[child.tagName] ?? [];
    for (const attr of Array.from(child.attributes)) {
      if (!allowed.includes(attr.name) || /^\s*javascript:/i.test(attr.value)) {
        child.removeAttribute(attr.name);
      }
    }
  }
}

function escapeHtml(text: string) {
  return text.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]!);
}

function escapeAttr(text: string) {
  return escapeHtml(text).replace(/'/g, '&#39;');
}
