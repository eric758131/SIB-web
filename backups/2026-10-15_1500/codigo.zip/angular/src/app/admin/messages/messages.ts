import { ChangeDetectionStrategy, Component, OnInit, inject, input, numberAttribute, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { AdminApiService } from '../../core/admin-api.service';
import { Message } from '../../core/models';
import { Icon } from '../../shared/icon';
import { queryText } from '../../shared/route-input';
import { ConfirmService } from '../../shared/confirm.service';
import { ToastService } from '../../shared/toast.service';
import { avatarColor, initials } from '../shared/avatar';
import { errorMessage } from '../shared/errors';

/** Submissions of the contact form ("Contacto" page). */
@Component({
  selector: 'app-messages',
  imports: [DatePipe, Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './messages.html',
  styleUrl: './messages.scss',
})
export class Messages implements OnInit {
  private api = inject(AdminApiService);
  private toast = inject(ToastService);
  private confirm = inject(ConfirmService);

  readonly estado = input('all', { transform: queryText('all') });
  readonly ver = input(null, { transform: (v: unknown) => (v ? numberAttribute(v) : null) });

  protected readonly avatarColor = avatarColor;
  protected readonly initials = initials;

  protected readonly tabs = [
    { value: 'all', label: 'Todos' },
    { value: 'unread', label: 'Sin leer' },
    { value: 'read', label: 'Leídos' },
    { value: 'trash', label: 'Papelera' },
  ];

  protected readonly status = signal('all');
  protected readonly items = signal<Message[]>([]);
  protected readonly counts = signal<Record<string, number>>({});
  protected readonly selected = signal<Message | null>(null);
  protected readonly loading = signal(true);
  protected readonly error = signal<string | null>(null);
  protected readonly page = signal(1);
  protected readonly lastPage = signal(1);
  protected readonly total = signal(0);
  private query = '';

  ngOnInit() {
    this.status.set(this.estado() || 'all');
    this.load(1);
    const id = this.ver();
    if (id) this.open(id);
  }

  protected setStatus(status: string) {
    this.status.set(status);
    this.selected.set(null);
    this.load(1);
  }

  protected search(q: string) {
    this.query = q.trim();
    this.load(1);
  }

  protected load(page: number) {
    this.loading.set(true);
    this.api.messages({ status: this.status(), q: this.query, page }).subscribe({
      next: (res) => {
        this.items.set(res.data);
        this.counts.set(res.counts);
        this.page.set(res.meta.current_page);
        this.lastPage.set(res.meta.last_page);
        this.total.set(res.meta.total);
        this.loading.set(false);
      },
      error: (e) => {
        this.error.set(errorMessage(e));
        this.loading.set(false);
      },
    });
  }

  protected open(id: number) {
    this.api.message(id).subscribe({
      next: ({ data }) => {
        this.selected.set(data);
        this.replace(data);
      },
      error: (e) => this.error.set(errorMessage(e)),
    });
  }

  protected setMessageStatus(message: Message, status: Message['status']) {
    this.api.setMessageStatus(message.id, status).subscribe({
      next: ({ data }) => {
        const labels = { trash: 'Mensaje movido a la papelera.', read: message.status === 'trash' ? 'Mensaje restaurado.' : 'Marcado como leído.', unread: 'Marcado como no leído.' };
        this.toast.success(labels[status]);
        if (status === 'trash' || (this.status() !== 'all' && this.status() !== status)) {
          this.selected.set(null);
          this.load(this.page());
        } else {
          this.selected.set(data);
          this.replace(data);
          this.load(this.page());
        }
      },
      error: (e) => this.error.set(errorMessage(e)),
    });
  }

  protected async destroy(message: Message) {
    const ok = await this.confirm.ask({
      title: '¿Eliminar definitivamente?',
      message: `El mensaje de «${message.name || 'sin nombre'}» se borrará para siempre.`,
      confirmText: 'Eliminar mensaje',
      danger: true,
    });
    if (!ok) return;

    this.api.deleteMessage(message.id).subscribe({
      next: () => {
        this.toast.success('Mensaje eliminado.');
        this.selected.set(null);
        this.load(this.page());
      },
      error: (e) => this.toast.error(errorMessage(e)),
    });
  }

  /** wa.me link; Bolivian numbers without country code get +591. */
  protected whatsappLink(phone: string) {
    const digits = phone.replace(/\D/g, '');
    return `https://wa.me/${digits.length <= 8 ? '591' + digits : digits}`;
  }

  private replace(message: Message) {
    this.items.update((list) => list.map((m) => (m.id === message.id ? message : m)));
  }
}
