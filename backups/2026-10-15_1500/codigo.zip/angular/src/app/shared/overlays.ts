import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { ConfirmService } from './confirm.service';
import { Icon } from './icon';
import { ToastService } from './toast.service';

/** Global toasts and confirmation dialog, mounted once in the app root. */
@Component({
  selector: 'app-overlays',
  imports: [Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: { '(document:keydown.escape)': 'confirm.pending() && confirm.answer(false)' },
  template: `
    <div class="toasts" aria-live="polite" aria-atomic="false">
      @for (t of toast.toasts(); track t.id) {
        <div class="toast" [class]="'toast toast--' + t.type" role="status">
          <span class="toast-icon">
            <app-icon [name]="t.type === 'success' ? 'check' : t.type === 'error' ? 'close' : 'inbox'" [size]="16" [stroke]="2.4" />
          </span>
          <p>{{ t.text }}</p>
          <button type="button" aria-label="Cerrar" (click)="toast.dismiss(t.id)"><app-icon name="close" [size]="16" /></button>
        </div>
      }
    </div>

    @if (confirm.pending(); as c) {
      <div class="backdrop" (click)="confirm.answer(false)">
        <div class="dialog" role="alertdialog" aria-modal="true" aria-labelledby="confirm-title" aria-describedby="confirm-msg" (click)="$event.stopPropagation()">
          <div class="dialog-icon" [class.danger]="c.danger">
            <app-icon [name]="c.danger ? 'trash' : 'shield'" [size]="26" [stroke]="1.7" />
          </div>
          <h2 id="confirm-title">{{ c.title }}</h2>
          <p id="confirm-msg">{{ c.message }}</p>
          <div class="actions">
            <button type="button" class="btn btn--ghost" (click)="confirm.answer(false)">Cancelar</button>
            <button type="button" class="btn" [class.btn--danger]="c.danger" (click)="confirm.answer(true)" autofocus>
              {{ c.confirmText ?? 'Confirmar' }}
            </button>
          </div>
        </div>
      </div>
    }
  `,
  styles: `
    .toasts {
      position: fixed;
      right: 20px;
      bottom: 20px;
      z-index: 200;
      display: flex;
      flex-direction: column;
      gap: 10px;
      width: min(380px, calc(100vw - 40px));
    }
    .toast {
      display: flex;
      align-items: flex-start;
      gap: 0.75rem;
      padding: 0.85rem 0.9rem;
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 12px 40px rgba(1, 17, 12, 0.18), 0 0 0 1px rgba(1, 17, 12, 0.05);
      animation: toast-in 0.35s cubic-bezier(0.2, 0.9, 0.3, 1.2);
      p { flex: 1; margin: 0.1rem 0 0; font-size: 0.92rem; color: var(--c-heading); line-height: 1.45; }
      button { border: 0; background: none; color: #9aa29f; cursor: pointer; padding: 2px; border-radius: 4px; &:hover { color: var(--c-heading); } }
    }
    .toast-icon { display: grid; place-items: center; width: 26px; height: 26px; border-radius: 50%; flex-shrink: 0; color: #fff; }
    .toast--success .toast-icon { background: var(--c-primary); }
    .toast--error .toast-icon { background: var(--c-danger); }
    .toast--info .toast-icon { background: #3b6fb6; }
    @keyframes toast-in { from { opacity: 0; transform: translateY(16px) scale(0.96); } }

    .backdrop {
      position: fixed;
      inset: 0;
      z-index: 190;
      display: grid;
      place-items: center;
      padding: 1rem;
      background: rgba(1, 17, 12, 0.45);
      backdrop-filter: blur(3px);
      animation: fade 0.2s ease;
    }
    .dialog {
      width: 100%;
      max-width: 420px;
      padding: 1.75rem 1.75rem 1.4rem;
      background: #fff;
      border-radius: 18px;
      box-shadow: 0 30px 80px rgba(0, 0, 0, 0.3);
      text-align: center;
      animation: pop 0.25s cubic-bezier(0.2, 0.9, 0.3, 1.2);
      h2 { font: 700 1.2rem var(--f-body); text-transform: none; margin: 1rem 0 0.4rem; }
      p { color: #6b7270; margin: 0 0 1.5rem; font-size: 0.95rem; }
    }
    .dialog-icon {
      display: inline-grid;
      place-items: center;
      width: 60px;
      height: 60px;
      border-radius: 50%;
      background: var(--c-soft);
      color: var(--c-primary);
      &.danger { background: #fdecea; color: var(--c-danger); }
    }
    .actions { display: flex; gap: 0.6rem; justify-content: center; .btn { min-width: 130px; } }
    @keyframes fade { from { opacity: 0; } }
    @keyframes pop { from { opacity: 0; transform: scale(0.92); } }
  `,
})
export class Overlays {
  protected readonly toast = inject(ToastService);
  protected readonly confirm = inject(ConfirmService);
}
