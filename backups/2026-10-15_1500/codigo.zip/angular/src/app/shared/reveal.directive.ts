import { Directive, ElementRef, PLATFORM_ID, afterNextRender, inject, input } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

/**
 * Fades/slides an element in when it scrolls into view.
 * Content stays visible without JavaScript or with reduced motion (and in server-rendered HTML).
 */
@Directive({
  selector: '[appReveal]',
})
export class Reveal {
  /** Delay in ms, to stagger items in a grid. */
  readonly appReveal = input<number | string>('');

  constructor() {
    const el = inject(ElementRef<HTMLElement>).nativeElement as HTMLElement;
    if (!isPlatformBrowser(inject(PLATFORM_ID))) return;

    afterNextRender(() => {
      if (!('IntersectionObserver' in window) || matchMedia('(prefers-reduced-motion: reduce)').matches) return;

      // Already on screen at load: don't animate (avoids a flash of hidden content).
      const rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.9) return;

      el.classList.add('reveal');
      const delay = Number(this.appReveal()) || 0;
      if (delay) el.style.transitionDelay = `${delay}ms`;

      const observer = new IntersectionObserver(
        (entries) => {
          if (entries.some((e) => e.isIntersecting)) {
            el.classList.add('is-visible');
            observer.disconnect();
          }
        },
        { rootMargin: '0px 0px -8% 0px' },
      );
      observer.observe(el);
    });
  }
}
