/**
 * Transforms for inputs bound from the URL (withComponentInputBinding).
 * When a query param is missing the router sets the input to `undefined`,
 * replacing its default value, so these map it back to a usable default.
 */
export function queryText(fallback = '') {
  return (value: unknown): string => (value === undefined || value === null || value === '' ? fallback : String(value));
}
