import { ChangeDetectionStrategy, Component, computed, effect, inject, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { SeoService } from '../../../core/seo.service';
import { CONTACT_INFO, TRAMITES } from '../../../core/site-content';
import { Icon } from '../../../shared/icon';
import { PageHero } from '../../shared/page-hero';

/** Requirement sheet of one registration procedure. */
@Component({
  selector: 'app-tramite',
  imports: [PageHero, RouterLink, Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let t = current();
    <app-page-hero [title]="t.title" [eyebrow]="t.code" crumb="Requisitos" />

    <section class="section">
      <div class="container layout">
        <div class="sheet-wrap">
          <div class="toolbar">
            <span class="toolbar-title"><app-icon name="file" [size]="18" /> Hoja de requisitos</span>
            <div class="toolbar-actions">
              <a [href]="t.image" target="_blank" rel="noopener" class="btn btn--ghost btn--sm"><app-icon name="external" [size]="16" /> Tamaño completo</a>
              <a [href]="t.image" download class="btn btn--sm"><app-icon name="download" [size]="16" /> Descargar</a>
            </div>
          </div>
          <a [href]="t.image" target="_blank" rel="noopener" class="sheet">
            <img [src]="t.image" [alt]="'Requisitos: ' + t.title" />
          </a>
        </div>

        <aside>
          <div class="card">
            <h2>Otros trámites</h2>
            <ul>
              @for (o of others(); track o.slug) {
                <li>
                  <a [routerLink]="['/', o.slug]">
                    <span><small>{{ o.code }}</small>{{ o.title }}</span>
                    <app-icon name="chevron-right" [size]="16" />
                  </a>
                </li>
              }
            </ul>
          </div>

          <div class="help">
            <span class="help-icon"><app-icon name="chat" [size]="24" [stroke]="1.6" /></span>
            <h3>¿Dudas con este trámite?</h3>
            <p>Comunícate con nosotros antes de acercarte a nuestras oficinas.</p>
            <a [href]="'tel:' + info.phone" class="help-line"><app-icon name="phone" [size]="16" /> {{ info.phone }}</a>
            <a routerLink="/contact" class="btn btn--light btn--sm">Escríbenos <app-icon name="arrow-right" [size]="16" /></a>
          </div>
        </aside>
      </div>
    </section>
  `,
  styles: `
    :host ::ng-deep app-page-hero h1 { font-size: clamp(1.8rem, 4vw, 2.7rem); text-transform: none; }

    .layout {
      display: grid;
      grid-template-columns: minmax(0, 1fr) 360px;
      gap: clamp(2rem, 4vw, 3rem);
      align-items: start;
      @media (max-width: 960px) { grid-template-columns: 1fr; }
    }

    .sheet-wrap {
      border-radius: 20px;
      background: var(--c-soft);
      padding: clamp(0.75rem, 2vw, 1.25rem);
    }

    .toolbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 0.75rem;
      padding: 0.25rem 0.25rem 1rem;
    }

    .toolbar-title { display: inline-flex; align-items: center; gap: 0.5rem; font-weight: 700; color: var(--c-heading); app-icon { color: var(--c-primary); } }
    .toolbar-actions { display: flex; gap: 0.5rem; flex-wrap: wrap; }

    .sheet {
      display: block;
      border-radius: 12px;
      overflow: hidden;
      background: #fff;
      box-shadow: 0 20px 50px rgba(1, 17, 12, 0.1);
      cursor: zoom-in;

      img { width: 100%; margin-inline: auto; transition: transform 0.5s cubic-bezier(0.2, 0.7, 0.2, 1); }
      &:hover img { transform: scale(1.01); }
    }

    aside {
      position: sticky;
      top: 110px;
      display: grid;
      gap: 1.25rem;
      @media (max-width: 960px) { position: static; }
    }

    .card {
      padding: 1.6rem 1.5rem 1rem;
      border-radius: 20px;
      background: #fff;
      box-shadow: 0 0 0 1px rgba(1, 17, 12, 0.07), 0 20px 40px rgba(1, 17, 12, 0.05);

      h2 { font-size: 1.6rem; margin-bottom: 0.75rem; }
      ul { list-style: none; padding: 0; margin: 0; }
      li + li { border-top: 1px solid #e6edeb; }

      a {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 0.75rem;
        padding: 0.8rem 0.5rem;
        margin-inline: -0.5rem;
        border-radius: 10px;
        color: var(--c-heading);
        font-size: 0.92rem;
        line-height: 1.35;
        transition: background 0.2s, color 0.2s;

        app-icon { flex-shrink: 0; color: #a3b0ac; transition: transform 0.2s, color 0.2s; }
        &:hover { background: var(--c-soft); color: var(--c-primary); app-icon { color: var(--c-primary); transform: translateX(3px); } }
      }

      small { display: block; font-weight: 700; color: var(--c-primary); font-size: 0.72rem; letter-spacing: 0.06em; margin-bottom: 0.1rem; }
    }

    .help {
      position: relative;
      overflow: hidden;
      padding: 1.75rem 1.5rem;
      border-radius: 20px;
      background: linear-gradient(135deg, var(--c-dark), #06362a);
      color: #b9cbc4;

      &::after {
        content: '';
        position: absolute;
        right: -80px;
        bottom: -80px;
        width: 200px;
        height: 200px;
        border-radius: 50%;
        border: 1px solid rgba(127, 220, 185, 0.18);
      }

      h3 { color: #fff; font-size: 1.45rem; margin: 1rem 0 0.4rem; }
      p { font-size: 0.92rem; margin-bottom: 1rem; }
    }

    .help-icon { display: grid; place-items: center; width: 48px; height: 48px; border-radius: 14px; background: rgba(37, 142, 111, 0.35); color: #7fdcb9; }

    .help-line {
      display: flex;
      align-items: center;
      gap: 0.4rem;
      margin-bottom: 1.1rem;
      color: #fff;
      font-weight: 600;
      app-icon { color: #7fdcb9; }
      &:hover { color: #7fdcb9; }
    }
  `,
})
export class TramitePage {
  readonly tramite = input.required<string>();

  protected readonly info = CONTACT_INFO;
  protected readonly current = computed(() => TRAMITES.find((t) => t.slug === this.tramite())!);
  protected readonly others = computed(() => TRAMITES.filter((t) => t.slug !== this.tramite()));

  constructor() {
    const seo = inject(SeoService);
    effect(() => seo.set(this.current().title, `Requisitos: ${this.current().title} (${this.current().code}).`));
  }
}
