import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { SeoService } from '../../../core/seo.service';
import { ABOUT } from '../../../core/site-content';
import { Icon } from '../../../shared/icon';
import { Reveal } from '../../../shared/reveal.directive';
import { AboutSections } from '../../shared/about-sections';
import { PageHero } from '../../shared/page-hero';

@Component({
  selector: 'app-about',
  imports: [PageHero, AboutSections, RouterLink, Icon, Reveal],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <app-page-hero title="Acerca de" eyebrow="SIB La Paz">
      <p class="hero-text">{{ commitmentTitle }}</p>
    </app-page-hero>

    <app-about-sections />

    <section class="section">
      <div class="container">
        <a routerLink="/documentos-institucionales-sib-la-paz" class="docs-link" appReveal>
          <span class="docs-icon"><app-icon name="file" [size]="30" [stroke]="1.5" /></span>
          <span class="docs-text">
            <span class="eyebrow">Transparencia</span>
            <strong>Documentos Institucionales</strong>
            <span>Consulta el Estatuto Orgánico y Reglamento de la Sociedad de Ingenieros de Bolivia Departamental La Paz.</span>
          </span>
          <span class="btn btn--outline">Ver documentos <app-icon name="arrow-right" [size]="16" /></span>
        </a>
      </div>
    </section>
  `,
  styles: `
    .hero-text {
      max-width: 600px;
      margin: 1.25rem 0 0;
      font-size: 1.1rem;
      color: rgba(255, 255, 255, 0.82);
    }

    .docs-link {
      display: flex;
      align-items: center;
      gap: 1.5rem 2rem;
      flex-wrap: wrap;
      padding: clamp(1.5rem, 4vw, 2.5rem);
      border-radius: 24px;
      background:
        radial-gradient(circle at 100% 0%, rgba(37, 142, 111, 0.1), transparent 45%),
        var(--c-soft);
      color: var(--c-text);
      transition: transform 0.3s, box-shadow 0.3s;

      &:hover {
        transform: translateY(-4px);
        box-shadow: 0 24px 50px rgba(1, 17, 12, 0.1);
        color: var(--c-text);
        .btn { background: var(--c-primary); color: #fff; }
        .docs-icon { transform: rotate(-6deg) scale(1.05); }
      }
    }

    .docs-icon {
      display: grid;
      place-items: center;
      width: 72px;
      height: 72px;
      flex-shrink: 0;
      border-radius: 20px;
      background: linear-gradient(135deg, var(--c-primary), #2fa883);
      color: #fff;
      box-shadow: 0 12px 28px rgba(37, 142, 111, 0.35);
      transition: transform 0.3s;
    }

    .docs-text {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-width: 240px;
      .eyebrow { margin-bottom: 0.25rem; }
      strong { font: 600 1.75rem/1.2 var(--f-heading); color: var(--c-heading); margin-bottom: 0.3rem; }
    }
  `,
})
export class About {
  protected readonly commitmentTitle = ABOUT.commitmentTitle;

  constructor() {
    inject(SeoService).set('Acerca de', ABOUT.commitment);
  }
}
