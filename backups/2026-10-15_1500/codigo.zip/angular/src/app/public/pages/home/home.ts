import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../../core/api.service';
import { Post } from '../../../core/models';
import { SeoService } from '../../../core/seo.service';
import { HERO_IMAGE, TRAMITES } from '../../../core/site-content';
import { Icon } from '../../../shared/icon';
import { Reveal } from '../../../shared/reveal.directive';
import { AboutSections } from '../../shared/about-sections';
import { PageHero } from '../../shared/page-hero';
import { PostCard } from '../../shared/post-card';
import { PostCardSkeleton } from '../../shared/post-card-skeleton';

@Component({
  selector: 'app-home',
  imports: [PageHero, AboutSections, PostCard, PostCardSkeleton, RouterLink, Icon, Reveal, DatePipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './home.html',
  styleUrl: './home.scss',
})
export class Home {
  protected readonly posts = signal<Post[]>([]);
  protected readonly loading = signal(true);
  protected readonly failed = signal(false);
  protected readonly featured = computed(() => this.posts()[0]);
  protected readonly others = computed(() => this.posts().slice(1, 4));
  protected readonly tramites = TRAMITES.slice(0, 4);

  protected readonly quickLinks = [
    { icon: 'stamp', title: 'Trámites', text: 'Requisitos de inscripción y renovación de credencial.', path: '/services' },
    { icon: 'megaphone', title: 'Convocatorias', text: 'Convocatorias públicas de la SIB La Paz.', path: '/convocatorias' },
    { icon: 'award', title: 'Comité Electoral', text: 'Convocatoria y reglamento de elecciones 2026 - 2028.', path: '/comite-electoral' },
    { icon: 'file', title: 'Documentos', text: 'Estatuto Orgánico y Reglamento institucional.', path: '/documentos-institucionales-sib-la-paz' },
  ];

  constructor() {
    inject(SeoService).set(
      '',
      'Sociedad de Ingenieros de Bolivia Departamental La Paz: noticias, trámites de inscripción, convocatorias y servicios para socios.',
      HERO_IMAGE,
    );

    inject(ApiService)
      .posts({ perPage: 4 })
      .subscribe({
        next: (res) => {
          this.posts.set(res.data);
          this.loading.set(false);
        },
        error: () => {
          this.failed.set(true);
          this.loading.set(false);
        },
      });
  }
}
