import { ChangeDetectionStrategy, Component, PLATFORM_ID, RESPONSE_INIT, computed, inject, input, signal } from '@angular/core';
import { DatePipe, isPlatformBrowser } from '@angular/common';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { HttpErrorResponse } from '@angular/common/http';
import { RouterLink } from '@angular/router';
import { catchError, map, of, startWith, switchMap, tap } from 'rxjs';
import { ApiService } from '../../../core/api.service';
import { Post, PostDetail as PostDetailData } from '../../../core/models';
import { SeoService } from '../../../core/seo.service';
import { HERO_IMAGE } from '../../../core/site-content';
import { Icon } from '../../../shared/icon';
import { Reveal } from '../../../shared/reveal.directive';
import { ToastService } from '../../../shared/toast.service';
import { PageHero } from '../../shared/page-hero';
import { PostCard } from '../../shared/post-card';

type State = { status: 'loading' } | { status: 'not-found' } | { status: 'error' } | { status: 'ok'; detail: PostDetailData };

const SITE = 'https://siblpz.org.bo';

@Component({
  selector: 'app-post-detail',
  imports: [PageHero, PostCard, RouterLink, DatePipe, Icon, Reveal],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './post-detail.html',
  styleUrl: './post-detail.scss',
  host: {
    '(window:scroll)': 'onScroll()',
    '(document:keydown)': 'onKey($event)',
  },
})
export class PostDetail {
  private api = inject(ApiService);
  private seo = inject(SeoService);
  private toast = inject(ToastService);
  private response = inject(RESPONSE_INIT, { optional: true });
  private isBrowser = isPlatformBrowser(inject(PLATFORM_ID));

  readonly slug = input.required<string>();

  protected readonly heroImage = HERO_IMAGE;
  protected readonly progress = signal(0);

  /** Lightbox: images inside the article and the one being shown. */
  protected readonly gallery = signal<string[]>([]);
  protected readonly lightbox = signal<number | null>(null);

  protected readonly state = toSignal(
    toObservable(this.slug).pipe(
      switchMap((slug) =>
        this.api.post(slug).pipe(
          tap(({ data }) => this.seo.set(data.title, data.excerpt, data.cover_image)),
          map((detail): State => ({ status: 'ok', detail })),
          catchError((err: HttpErrorResponse) => {
            if (err.status === 404) {
              this.seo.set('Página no encontrada');
              if (this.response) this.response.status = 404;
              return of<State>({ status: 'not-found' });
            }
            return of<State>({ status: 'error' });
          }),
          startWith<State>({ status: 'loading' }),
        ),
      ),
    ),
    { initialValue: { status: 'loading' } as State },
  );

  protected readonly readingMinutes = computed(() => {
    const s = this.state();
    if (s.status !== 'ok') return 0;
    const words = (s.detail.data.content ?? '').replace(/<[^>]*>/g, ' ').trim().split(/\s+/).length;
    return Math.max(1, Math.round(words / 200));
  });

  /** The default "Uncategorized" category is shown as "Noticias". */
  protected categoryLabel(post: Post) {
    return post.categories.find((c) => c.slug !== 'uncategorized')?.name ?? 'Noticias';
  }

  protected shareUrl(post: Post) {
    return `${SITE}/${post.slug}/`;
  }

  protected share(network: 'facebook' | 'whatsapp' | 'x', post: Post) {
    const url = encodeURIComponent(this.shareUrl(post));
    const text = encodeURIComponent(post.title);
    const target = {
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${url}`,
      whatsapp: `https://wa.me/?text=${text}%20${url}`,
      x: `https://twitter.com/intent/tweet?text=${text}&url=${url}`,
    }[network];
    window.open(target, '_blank', 'noopener,width=640,height=560');
  }

  protected copyLink(post: Post) {
    navigator.clipboard?.writeText(this.shareUrl(post)).then(() => this.toast.success('Enlace copiado.'));
  }

  protected onScroll() {
    if (!this.isBrowser) return;
    const max = document.documentElement.scrollHeight - window.innerHeight;
    this.progress.set(max > 0 ? Math.min(100, (window.scrollY / max) * 100) : 0);
  }

  /** Clicking an image in the article opens it large. */
  protected onContentClick(event: MouseEvent) {
    const target = event.target as HTMLElement;
    if (target.tagName !== 'IMG') return;

    const article = event.currentTarget as HTMLElement;
    const images = Array.from(article.querySelectorAll('img')).map((img) => img.currentSrc || img.src);
    event.preventDefault();
    this.gallery.set(images);
    this.lightbox.set(images.indexOf((target as HTMLImageElement).currentSrc || (target as HTMLImageElement).src));
  }

  protected step(delta: number) {
    const i = this.lightbox();
    const total = this.gallery().length;
    if (i === null || !total) return;
    this.lightbox.set((i + delta + total) % total);
  }

  protected onKey(event: KeyboardEvent) {
    if (this.lightbox() === null) return;
    if (event.key === 'Escape') this.lightbox.set(null);
    if (event.key === 'ArrowRight') this.step(1);
    if (event.key === 'ArrowLeft') this.step(-1);
  }
}
