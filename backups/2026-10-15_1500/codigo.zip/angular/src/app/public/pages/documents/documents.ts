import { ChangeDetectionStrategy, Component, computed, effect, inject, input } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { SeoService } from '../../../core/seo.service';
import { DOCUMENT_PAGES } from '../../../core/site-content';
import { Icon } from '../../../shared/icon';
import { Reveal } from '../../../shared/reveal.directive';
import { CtaBand } from '../../shared/cta-band';
import { PageHero } from '../../shared/page-hero';

/** Comité Electoral, Convocatorias, Convocatorias SIB Nacional and Documentos Institucionales. */
@Component({
  selector: 'app-documents',
  imports: [PageHero, CtaBand, Icon, Reveal, RouterLink, RouterLinkActive],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @let p = page();
    <app-page-hero [title]="p.title" eyebrow="SIB La Paz">
      <p class="hero-meta">
        <app-icon name="file" [size]="16" />
        {{ p.documents.length }} {{ p.documents.length === 1 ? 'documento disponible' : 'documentos disponibles' }}
      </p>
    </app-page-hero>

    <section class="section">
      <div class="container">
        <nav class="tabs" aria-label="Secciones de documentos" appReveal>
          @for (o of pages; track o.slug) {
            <a [routerLink]="['/', o.slug]" routerLinkActive="is-active" ariaCurrentWhenActive="page">{{ o.title }}</a>
          }
        </nav>

        <div class="docs">
          @for (doc of p.documents; track doc.file; let i = $index) {
            <article class="doc" appReveal>
              <a [href]="doc.file" target="_blank" rel="noopener" class="doc-thumb" [attr.aria-label]="'Abrir ' + doc.title">
                <span class="paper" aria-hidden="true"></span>
                <img [src]="doc.thumbnail" [alt]="doc.title" loading="lazy" />
                <span class="overlay" aria-hidden="true"><app-icon name="eye" [size]="26" /> Ver documento</span>
                <span class="pdf" aria-hidden="true">PDF</span>
              </a>
              <div class="doc-body">
                <span class="doc-num" aria-hidden="true">{{ i + 1 < 10 ? '0' + (i + 1) : i + 1 }}</span>
                <span class="chip"><span class="dot"></span>{{ doc.label }}</span>
                <h2>{{ doc.title }}</h2>
                @if (doc.description) {
                  <p>{{ doc.description }}</p>
                }
                <div class="actions">
                  <a [href]="doc.file" target="_blank" rel="noopener" class="btn"><app-icon name="eye" [size]="18" /> Ver documento</a>
                  <a [href]="doc.file" download class="btn btn--outline"><app-icon name="download" [size]="18" /> Descargar PDF</a>
                </div>
              </div>
            </article>
          }
        </div>
      </div>
    </section>

    <app-cta-band title="¿Tienes consultas sobre estos documentos?" />
  `,
  styles: `
    .hero-meta {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      margin: 1.25rem 0 0;
      color: rgba(255, 255, 255, 0.8);
      font-size: 0.95rem;
    }

    .tabs {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 0.5rem;
      margin: 0 auto 3.5rem;
      padding: 0.4rem;
      width: fit-content;
      max-width: 100%;
      border-radius: 999px;
      background: var(--c-soft);

      a {
        padding: 0.55rem 1.1rem;
        border-radius: 999px;
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--c-text);
        transition: background 0.2s, color 0.2s, box-shadow 0.2s;
        &:hover { color: var(--c-primary); }
        &.is-active { background: #fff; color: var(--c-primary); box-shadow: 0 4px 14px rgba(1, 17, 12, 0.08); }
      }

      @media (max-width: 640px) { border-radius: 16px; }
    }

    .docs { display: grid; gap: clamp(2rem, 5vw, 3.5rem); }

    .doc {
      display: grid;
      grid-template-columns: minmax(0, 360px) 1fr;
      gap: clamp(2rem, 5vw, 4.5rem);
      align-items: center;
      padding: clamp(1.5rem, 4vw, 3rem);
      border-radius: 24px;
      background:
        radial-gradient(circle at 100% 0%, rgba(37, 142, 111, 0.08), transparent 40%),
        var(--c-soft);

      &:nth-child(even) {
        grid-template-columns: 1fr minmax(0, 360px);
        .doc-thumb { order: 2; }
      }

      @media (max-width: 760px) {
        grid-template-columns: 1fr !important;
        .doc-thumb { order: 0 !important; }
      }
    }

    .doc-thumb {
      position: relative;
      display: block;
      max-width: 360px;
      width: 100%;
      margin-inline: auto;

      img {
        position: relative;
        width: 100%;
        max-height: 460px;
        object-fit: contain;
        border-radius: 8px;
        background: #fff;
        box-shadow: 0 24px 50px rgba(1, 17, 12, 0.16);
        transition: transform 0.4s cubic-bezier(0.2, 0.7, 0.2, 1);
      }

      &:hover img { transform: translateY(-6px); }
      &:hover .overlay { opacity: 1; }
    }

    /* Second sheet peeking behind the cover */
    .paper {
      position: absolute;
      inset: 10px -10px -10px 10px;
      border-radius: 8px;
      background: #fff;
      box-shadow: 0 10px 30px rgba(1, 17, 12, 0.08);
      transform: rotate(3deg);
    }

    .overlay {
      position: absolute;
      inset: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 0.5rem;
      border-radius: 8px;
      background: rgba(1, 17, 12, 0.6);
      backdrop-filter: blur(2px);
      color: #fff;
      font-weight: 600;
      opacity: 0;
      transition: opacity 0.3s;
    }

    .pdf {
      position: absolute;
      top: 14px;
      left: -10px;
      padding: 0.3rem 0.7rem;
      border-radius: 6px;
      background: #c0392b;
      color: #fff;
      font-size: 0.75rem;
      font-weight: 800;
      letter-spacing: 0.08em;
      box-shadow: 0 6px 16px rgba(192, 57, 43, 0.35);
    }

    .doc-body { position: relative; }

    .doc-num {
      position: absolute;
      top: -1.5rem;
      right: 0;
      font: 600 6rem/1 var(--f-heading);
      color: rgba(37, 142, 111, 0.1);
      pointer-events: none;
    }

    .chip {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.3rem 0.8rem;
      border-radius: 999px;
      background: #fff;
      font-size: 0.78rem;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-primary);
      box-shadow: 0 0 0 1px rgba(37, 142, 111, 0.15);
    }
    .dot { width: 6px; height: 6px; border-radius: 50%; background: var(--c-primary); }

    h2 { font-size: clamp(1.8rem, 3.2vw, 2.5rem); margin: 1rem 0 0.75rem; }
    p { font-size: 1.12rem; }
    .actions { display: flex; flex-wrap: wrap; gap: 0.75rem; margin-top: 1.75rem; }
  `,
})
export class Documents {
  /** Route data: key in DOCUMENT_PAGES. */
  readonly pageKey = input.required<string>({ alias: 'page' });
  protected readonly page = computed(() => DOCUMENT_PAGES[this.pageKey()]);
  protected readonly pages = Object.entries(DOCUMENT_PAGES).map(([slug, p]) => ({ slug, title: p.title }));

  constructor() {
    const seo = inject(SeoService);
    effect(() => {
      const p = this.page();
      seo.set(p.title, p.documents.map((d) => d.description ?? d.title).join(' · '));
    });
  }
}
