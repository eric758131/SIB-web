import { ChangeDetectionStrategy, Component, RESPONSE_INIT, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { SeoService } from '../../../core/seo.service';
import { Icon } from '../../../shared/icon';
import { PageHero } from '../../shared/page-hero';

@Component({
  selector: 'app-not-found',
  imports: [PageHero, RouterLink, Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <app-page-hero title="Página no encontrada" eyebrow="Error 404" />
    <section class="section">
      <div class="container center">
        <div class="code" aria-hidden="true">4<span>0</span>4</div>
        <p class="lead">La página que buscas no existe o fue movida. Estos enlaces pueden ayudarte:</p>

        <div class="links">
          @for (l of links; track l.path) {
            <a [routerLink]="l.path" class="link">
              <span class="link-icon"><app-icon [name]="l.icon" [size]="22" [stroke]="1.6" /></span>
              {{ l.label }}
            </a>
          }
        </div>

        <a routerLink="/" class="btn"><app-icon name="home" [size]="18" /> Volver al inicio</a>
      </div>
    </section>
  `,
  styles: `
    .center { text-align: center; }

    .code {
      font: 600 clamp(6rem, 18vw, 11rem)/1 var(--f-heading);
      color: var(--c-heading);
      letter-spacing: 0.02em;
      span {
        display: inline-block;
        color: transparent;
        background: linear-gradient(135deg, var(--c-primary), #7fdcb9);
        -webkit-background-clip: text;
        background-clip: text;
        animation: float 3.5s ease-in-out infinite;
      }
    }

    .lead { max-width: 520px; margin: 1rem auto 2rem; font-size: 1.1rem; }

    .links {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 0.75rem;
      max-width: 760px;
      margin: 0 auto 2.5rem;
      @media (max-width: 700px) { grid-template-columns: repeat(2, 1fr); }
    }

    .link {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 0.6rem;
      padding: 1.25rem 0.75rem;
      border-radius: 16px;
      background: var(--c-soft);
      color: var(--c-heading);
      font-weight: 600;
      font-size: 0.95rem;
      transition: transform 0.3s, box-shadow 0.3s, background 0.3s;
      &:hover { transform: translateY(-4px); background: #fff; box-shadow: 0 18px 40px rgba(1, 17, 12, 0.1); color: var(--c-primary); }
    }

    .link-icon { display: grid; place-items: center; width: 48px; height: 48px; border-radius: 14px; background: #fff; color: var(--c-primary); }

    @keyframes float { 50% { transform: translateY(-12px); } }
  `,
})
export class NotFound {
  protected readonly links = [
    { path: '/services', label: 'Servicios', icon: 'briefcase' },
    { path: '/blog', label: 'Noticias', icon: 'newspaper' },
    { path: '/about', label: 'Acerca de', icon: 'users' },
    { path: '/contact', label: 'Contacto', icon: 'mail' },
  ];

  constructor() {
    inject(SeoService).set('Página no encontrada');
    const response = inject(RESPONSE_INIT, { optional: true });
    if (response) response.status = 404;
  }
}
