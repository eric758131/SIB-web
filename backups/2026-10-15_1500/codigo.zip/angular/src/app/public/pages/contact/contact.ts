import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { DomSanitizer } from '@angular/platform-browser';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { ApiService } from '../../../core/api.service';
import { SeoService } from '../../../core/seo.service';
import { CONTACT_INFO, FAQ, SOCIAL_LINKS } from '../../../core/site-content';
import { Icon } from '../../../shared/icon';
import { Reveal } from '../../../shared/reveal.directive';
import { PageHero } from '../../shared/page-hero';

@Component({
  selector: 'app-contact',
  imports: [PageHero, ReactiveFormsModule, Icon, Reveal],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './contact.html',
  styleUrl: './contact.scss',
})
export class Contact {
  private api = inject(ApiService);

  protected readonly info = CONTACT_INFO;
  protected readonly social = SOCIAL_LINKS;
  protected readonly faq = FAQ;
  protected readonly openFaq = signal<number | null>(0);

  protected readonly whatsappUrl = `https://wa.me/591${CONTACT_INFO.phone.replace(/\D/g, '')}`;
  protected readonly mapUrl = inject(DomSanitizer).bypassSecurityTrustResourceUrl(
    `https://www.google.com/maps?q=${encodeURIComponent(CONTACT_INFO.address)}&output=embed`,
  );

  protected readonly sending = signal(false);
  protected readonly sent = signal<string | null>(null);
  protected readonly error = signal<string | null>(null);

  protected readonly form = inject(FormBuilder).nonNullable.group({
    name: ['', [Validators.required, Validators.maxLength(255)]],
    email: ['', [Validators.required, Validators.email]],
    phone: ['', [Validators.maxLength(50)]],
    message: ['', [Validators.required, Validators.maxLength(5000)]],
    website: [''], // honeypot
  });

  private readonly message = toSignal(this.form.controls.message.valueChanges, { initialValue: '' });
  protected readonly messageLength = computed(() => this.message().length);

  constructor() {
    inject(SeoService).set('Contacto', `Comuníquese con la SIB La Paz: ${CONTACT_INFO.phone} · ${CONTACT_INFO.email}`);
  }

  protected invalid(name: 'name' | 'email' | 'message') {
    const control = this.form.controls[name];
    return control.invalid && (control.touched || control.dirty);
  }

  protected toggleFaq(index: number) {
    this.openFaq.update((current) => (current === index ? null : index));
  }

  protected submit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.sending.set(true);
    this.error.set(null);

    this.api.contact(this.form.getRawValue()).subscribe({
      next: (res) => {
        this.sent.set(res.message);
        this.form.reset();
        this.sending.set(false);
      },
      error: (err: HttpErrorResponse) => {
        this.error.set(
          err.status === 429
            ? 'Has enviado varios mensajes seguidos. Espera un minuto e inténtalo de nuevo.'
            : 'No se pudo enviar el mensaje. Revisa los datos e inténtalo nuevamente.',
        );
        this.sending.set(false);
      },
    });
  }
}
