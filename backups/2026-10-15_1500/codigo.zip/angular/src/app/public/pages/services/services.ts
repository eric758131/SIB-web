import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { SeoService } from '../../../core/seo.service';
import { HERO_IMAGE, SERVICES, TRAMITES } from '../../../core/site-content';
import { Icon } from '../../../shared/icon';
import { Reveal } from '../../../shared/reveal.directive';
import { CtaBand } from '../../shared/cta-band';
import { PageHero } from '../../shared/page-hero';

@Component({
  selector: 'app-services',
  imports: [PageHero, CtaBand, RouterLink, Icon, Reveal],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './services.html',
  styleUrl: './services.scss',
})
export class Services {
  protected readonly tramites = TRAMITES;
  protected readonly services = SERVICES;
  protected readonly image = HERO_IMAGE;
  protected readonly icons = ['stamp', 'chat', 'graduation'];

  constructor() {
    inject(SeoService).set(
      'Servicios',
      'Requisitos de inscripción, renovación de credencial, licencia de extranjero, legalización de documentos y más servicios de la SIB La Paz.',
    );
  }
}
