import { ChangeDetectionStrategy, Component, computed, inject, input, numberAttribute } from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { Router, RouterLink } from '@angular/router';
import { catchError, map, of, startWith, switchMap } from 'rxjs';
import { ApiService } from '../../../core/api.service';
import { Paginated, Post } from '../../../core/models';
import { SeoService } from '../../../core/seo.service';
import { Icon } from '../../../shared/icon';
import { queryText } from '../../../shared/route-input';
import { PageHero } from '../../shared/page-hero';
import { PostCard } from '../../shared/post-card';
import { PostCardSkeleton } from '../../shared/post-card-skeleton';
import { Reveal } from '../../../shared/reveal.directive';

interface ListState {
  loading: boolean;
  error: boolean;
  result: Paginated<Post> | null;
}

@Component({
  selector: 'app-news-list',
  imports: [PageHero, PostCard, PostCardSkeleton, RouterLink, Icon, Reveal],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './news-list.html',
  styleUrl: './news-list.scss',
})
export class NewsList {
  private api = inject(ApiService);
  private router = inject(Router);

  // Query params (?pagina=2&buscar=...&categoria=...)
  readonly pagina = input(1, { transform: (v: unknown) => numberAttribute(v, 1) });
  readonly buscar = input('', { transform: queryText() });
  readonly categoria = input('', { transform: queryText() });

  protected readonly categories = toSignal(this.api.categories().pipe(catchError(() => of([]))), { initialValue: [] });

  private readonly filters = computed(() => ({
    page: Math.max(this.pagina(), 1),
    q: this.buscar() ?? '',
    category: this.categoria() ?? '',
  }));

  protected readonly state = toSignal(
    toObservable(this.filters).pipe(
      switchMap((f) =>
        this.api.posts({ page: f.page, perPage: 9, q: f.q, category: f.category }).pipe(
          map((result): ListState => ({ loading: false, error: false, result })),
          catchError(() => of<ListState>({ loading: false, error: true, result: null })),
          startWith<ListState>({ loading: true, error: false, result: null }),
        ),
      ),
    ),
    { initialValue: { loading: true, error: false, result: null } as ListState },
  );

  protected readonly pages = computed(() => {
    const meta = this.state().result?.meta;
    if (!meta || meta.last_page <= 1) return [];
    const current = meta.current_page;
    const last = meta.last_page;
    const set = new Set([1, last, current - 1, current, current + 1].filter((p) => p >= 1 && p <= last));
    return [...set].sort((a, b) => a - b);
  });

  constructor() {
    inject(SeoService).set('Noticias', 'Noticias y comunicados de la Sociedad de Ingenieros de Bolivia Departamental La Paz.');
  }

  protected search(term: string) {
    this.router.navigate([], {
      queryParams: { buscar: term.trim() || null, pagina: null },
      queryParamsHandling: 'merge',
    });
  }

  protected query(page: number) {
    return { pagina: page > 1 ? page : null, buscar: this.buscar() || null, categoria: this.categoria() || null };
  }
}
