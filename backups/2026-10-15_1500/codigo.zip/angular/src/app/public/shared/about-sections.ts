import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ABOUT, HERO_IMAGE } from '../../core/site-content';
import { Icon } from '../../shared/icon';
import { Reveal } from '../../shared/reveal.directive';
import { Counter } from './counter';

/** Institutional sections shared by the "Inicio" and "Acerca de" pages. */
@Component({
  selector: 'app-about-sections',
  imports: [RouterLink, Icon, Counter, Reveal],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './about-sections.html',
  styleUrl: './about-sections.scss',
})
export class AboutSections {
  protected readonly about = ABOUT;
  protected readonly image = HERO_IMAGE;
}
