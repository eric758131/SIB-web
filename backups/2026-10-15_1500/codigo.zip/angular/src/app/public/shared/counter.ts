import { ChangeDetectionStrategy, Component, ElementRef, PLATFORM_ID, afterNextRender, inject, input, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

/** Number that counts up when it scrolls into view (uagb/counter). */
@Component({
  selector: 'app-counter',
  changeDetection: ChangeDetectionStrategy.OnPush,
  // Shows the final value until the animation starts, so server-rendered HTML is correct.
  template: `{{ animating() ? current() : value() }}{{ suffix() }}`,
})
export class Counter {
  readonly value = input.required<number>();
  readonly suffix = input('');

  protected readonly current = signal(0);
  protected readonly animating = signal(false);

  constructor() {
    const el = inject(ElementRef<HTMLElement>);
    const isBrowser = isPlatformBrowser(inject(PLATFORM_ID));

    afterNextRender(() => {
      if (!isBrowser || !('IntersectionObserver' in window) || matchMedia('(prefers-reduced-motion: reduce)').matches) {
        return;
      }

      const observer = new IntersectionObserver((entries) => {
        if (!entries.some((e) => e.isIntersecting)) return;
        observer.disconnect();
        this.animate();
      });
      observer.observe(el.nativeElement);
    });
  }

  private animate() {
    const target = this.value();
    const duration = 1600;
    const start = performance.now();
    this.current.set(0);
    this.animating.set(true);

    const step = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      this.current.set(Math.round(target * (1 - Math.pow(1 - progress, 3))));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }
}
