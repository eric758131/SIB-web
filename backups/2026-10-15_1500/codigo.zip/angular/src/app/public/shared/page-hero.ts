import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { HERO_IMAGE } from '../../core/site-content';
import { Icon } from '../../shared/icon';

/** Title banner at the top of each page, under the transparent header. */
@Component({
  selector: 'app-page-hero',
  imports: [RouterLink, Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section class="hero" [class.hero--large]="large()">
      <div class="bg" [style.background-image]="'url(' + image() + ')'"></div>
      <div class="pattern" aria-hidden="true"></div>
      <div class="container hero-content">
        @if (!large()) {
          <nav class="crumbs" aria-label="Ruta de navegación">
            <a routerLink="/"><app-icon name="home" [size]="14" /> Inicio</a>
            <app-icon name="chevron-right" [size]="14" />
            <span>{{ crumb() || title() }}</span>
          </nav>
        }
        @if (eyebrow()) {
          <span class="eyebrow"><span class="dot"></span>{{ eyebrow() }}</span>
        }
        <h1>{{ title() }}</h1>
        <ng-content />
      </div>
      <svg class="curve" viewBox="0 0 1440 60" preserveAspectRatio="none" aria-hidden="true">
        <path d="M0 60V30C240 0 480 0 720 22s480 38 720 8v30Z" />
      </svg>
    </section>
  `,
  styles: `
    :host { display: block; }

    .hero {
      position: relative;
      display: flex;
      align-items: flex-end;
      min-height: 420px;
      padding: 170px 0 90px;
      overflow: hidden;
      background: var(--c-dark);
      color: #fff;
      isolation: isolate;
    }

    .bg {
      position: absolute;
      inset: 0;
      z-index: -3;
      background: center / cover no-repeat;
      transform: scale(1.06);
      animation: zoom-out 1.6s cubic-bezier(0.2, 0.7, 0.2, 1) forwards;
    }

    .hero::before {
      content: '';
      position: absolute;
      inset: 0;
      z-index: -2;
      background:
        linear-gradient(100deg, rgba(1, 17, 12, 0.92) 0%, rgba(1, 17, 12, 0.72) 45%, rgba(21, 129, 96, 0.35) 100%),
        linear-gradient(180deg, rgba(1, 17, 12, 0.5) 0%, transparent 35%);
    }

    .pattern {
      position: absolute;
      inset: 0;
      z-index: -1;
      opacity: 0.35;
      background-image: radial-gradient(rgba(127, 220, 185, 0.35) 1px, transparent 1px);
      background-size: 22px 22px;
      mask-image: linear-gradient(90deg, transparent 40%, #000 100%);
    }

    .hero--large {
      min-height: min(100vh, 820px);
      align-items: center;
      padding-bottom: 150px;
      h1 { font-size: clamp(2.6rem, 6.5vw, 4.8rem); max-width: 920px; line-height: 1.08; }
    }

    .hero-content { position: relative; animation: rise 0.9s cubic-bezier(0.2, 0.7, 0.2, 1) both; }

    .crumbs {
      display: flex;
      align-items: center;
      gap: 0.4rem;
      margin-bottom: 1.25rem;
      font-size: 0.85rem;
      color: rgba(255, 255, 255, 0.7);
      a { display: inline-flex; align-items: center; gap: 0.3rem; color: rgba(255, 255, 255, 0.85); &:hover { color: #fff; } }
      span { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 50vw; }
    }

    .eyebrow {
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.35rem 0.85rem;
      border: 1px solid rgba(127, 220, 185, 0.35);
      border-radius: 999px;
      background: rgba(37, 142, 111, 0.18);
      color: #a6ead0;
      backdrop-filter: blur(4px);
    }
    .dot { width: 7px; height: 7px; border-radius: 50%; background: #7fdcb9; box-shadow: 0 0 0 4px rgba(127, 220, 185, 0.25); }

    h1 { color: #fff; margin: 1rem 0 0; max-width: 1000px; text-shadow: 0 2px 30px rgba(0, 0, 0, 0.3); }

    .curve {
      position: absolute;
      left: 0;
      right: 0;
      bottom: -1px;
      width: 100%;
      height: 50px;
      fill: var(--hero-curve, #fff);
    }

    @keyframes zoom-out { to { transform: scale(1); } }
    @keyframes rise { from { opacity: 0; transform: translateY(24px); } }
  `,
})
export class PageHero {
  readonly title = input.required<string>();
  readonly eyebrow = input<string>('');
  readonly image = input<string>(HERO_IMAGE);
  readonly large = input(false);
  /** Short breadcrumb label (defaults to the title). */
  readonly crumb = input<string>('');
}
