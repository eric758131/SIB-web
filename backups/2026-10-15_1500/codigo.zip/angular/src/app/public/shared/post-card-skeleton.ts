import { ChangeDetectionStrategy, Component } from '@angular/core';

/** Loading placeholder with the same shape as PostCard. */
@Component({
  selector: 'app-post-card-skeleton',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="card" aria-hidden="true">
      <div class="skeleton thumb"></div>
      <div class="body">
        <div class="skeleton line" style="width: 40%"></div>
        <div class="skeleton line big"></div>
        <div class="skeleton line big" style="width: 75%"></div>
        <div class="skeleton line"></div>
        <div class="skeleton line" style="width: 85%"></div>
      </div>
    </div>
  `,
  styles: `
    .card { background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 0 0 1px rgba(1, 17, 12, 0.06); }
    .thumb { aspect-ratio: 16 / 10; border-radius: 0; }
    .body { padding: 1.4rem 1.5rem 1.6rem; display: grid; gap: 0.7rem; }
    .line { height: 12px; }
    .big { height: 20px; }
  `,
})
export class PostCardSkeleton {}
