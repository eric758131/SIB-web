import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Post } from '../../core/models';
import { LOGO_URL } from '../../core/site-content';
import { Icon } from '../../shared/icon';

@Component({
  selector: 'app-post-card',
  imports: [RouterLink, DatePipe, Icon],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <article class="card" [class.card--featured]="featured()">
      <a [routerLink]="['/', post().slug]" class="thumb" tabindex="-1" aria-hidden="true">
        @if (post().cover_image) {
          <img [src]="post().cover_image" alt="" loading="lazy" />
        } @else {
          <div class="placeholder"><img [src]="logo" alt="" /></div>
        }
        <span class="chip">{{ category() }}</span>
      </a>
      <div class="body">
        <div class="meta">
          <app-icon name="calendar" [size]="14" />
          <time [attr.datetime]="post().published_at">{{ post().published_at | date: 'longDate' }}</time>
        </div>
        <h3><a [routerLink]="['/', post().slug]">{{ post().title }}</a></h3>
        <p>{{ post().excerpt }}</p>
        <a [routerLink]="['/', post().slug]" class="more">
          Leer noticia <span class="arrow"><app-icon name="arrow-right" [size]="15" /></span>
        </a>
      </div>
    </article>
  `,
  styles: `
    :host { display: block; height: 100%; }
    .card {
      display: flex;
      flex-direction: column;
      height: 100%;
      background: #fff;
      border-radius: 16px;
      overflow: hidden;
      box-shadow: 0 1px 2px rgba(1, 17, 12, 0.05), 0 0 0 1px rgba(1, 17, 12, 0.06);
      transition: transform 0.35s cubic-bezier(0.2, 0.7, 0.2, 1), box-shadow 0.35s;
      &:hover { transform: translateY(-6px); box-shadow: 0 24px 50px rgba(1, 17, 12, 0.12), 0 0 0 1px rgba(37, 142, 111, 0.2); }
    }
    .thumb {
      position: relative;
      display: block;
      aspect-ratio: 16 / 10;
      overflow: hidden;
      background: var(--c-soft);
      img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.6s cubic-bezier(0.2, 0.7, 0.2, 1); }
      &::after { content: ''; position: absolute; inset: 0; background: linear-gradient(180deg, transparent 55%, rgba(1, 17, 12, 0.35)); }
    }
    .card:hover .thumb img { transform: scale(1.07); }
    .chip {
      position: absolute;
      left: 14px;
      top: 14px;
      z-index: 1;
      padding: 0.3rem 0.75rem;
      border-radius: 999px;
      background: rgba(255, 255, 255, 0.92);
      backdrop-filter: blur(6px);
      color: var(--c-primary-dark);
      font-size: 0.72rem;
      font-weight: 700;
      letter-spacing: 0.06em;
      text-transform: uppercase;
    }
    .placeholder { display: grid; place-items: center; height: 100%; img { width: 80px; height: 80px; object-fit: contain; opacity: 0.45; } }
    .body { display: flex; flex-direction: column; flex: 1; padding: 1.4rem 1.5rem 1.5rem; }
    .meta { display: flex; align-items: center; gap: 0.4rem; font-size: 0.8rem; font-weight: 600; color: var(--c-primary); margin-bottom: 0.65rem; }
    h3 {
      font-size: 1.32rem;
      line-height: 1.28;
      margin-bottom: 0.65rem;
      text-transform: none;
      a { color: var(--c-heading); background: linear-gradient(var(--c-primary), var(--c-primary)) 0 100% / 0 1px no-repeat; transition: background-size 0.35s, color 0.2s; }
    }
    .card:hover h3 a { color: var(--c-primary-dark); background-size: 100% 1px; }
    p {
      font-size: 0.94rem;
      color: #62676a;
      display: -webkit-box;
      -webkit-line-clamp: 3;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }
    .more {
      margin-top: auto;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      font-weight: 600;
      font-size: 0.9rem;
    }
    .arrow {
      display: inline-grid;
      place-items: center;
      width: 28px;
      height: 28px;
      border-radius: 50%;
      background: var(--c-soft);
      transition: background 0.25s, color 0.25s, transform 0.25s;
    }
    .card:hover .arrow { background: var(--c-primary); color: #fff; transform: translateX(3px); }

    /* Large variant (first news on the home page) */
    .card--featured {
      .thumb { aspect-ratio: 16 / 9; }
      h3 { font-size: clamp(1.5rem, 2.4vw, 2rem); }
      .body { padding: 1.75rem 2rem 2rem; }
      p { -webkit-line-clamp: 4; font-size: 1rem; }
    }
  `,
})
export class PostCard {
  readonly post = input.required<Post>();
  readonly featured = input(false);
  protected readonly logo = LOGO_URL;

  protected readonly category = computed(
    () => this.post().categories.find((c) => c.slug !== 'uncategorized')?.name ?? 'Noticias',
  );
}
