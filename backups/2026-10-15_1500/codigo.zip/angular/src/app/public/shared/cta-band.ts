import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CONTACT_INFO } from '../../core/site-content';
import { Icon } from '../../shared/icon';
import { Reveal } from '../../shared/reveal.directive';

/** Dark closing band inviting the visitor to get in touch. */
@Component({
  selector: 'app-cta-band',
  imports: [RouterLink, Icon, Reveal],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section class="band">
      <div class="glow" aria-hidden="true"></div>
      <div class="container inner" appReveal>
        <div class="text">
          <span class="eyebrow">¿Necesitas ayuda?</span>
          <h2>{{ title() }}</h2>
          <p>{{ text() }}</p>
        </div>
        <div class="actions">
          <a routerLink="/contact" class="btn btn--light">Escríbenos <app-icon name="arrow-right" [size]="18" /></a>
          <div class="channels">
            <a [href]="'tel:' + info.phone"><app-icon name="phone" [size]="16" /> {{ info.phone }}</a>
            <a [href]="'mailto:' + info.email"><app-icon name="mail" [size]="16" /> {{ info.email }}</a>
          </div>
        </div>
      </div>
    </section>
  `,
  styles: `
    :host { display: block; }

    .band {
      position: relative;
      overflow: hidden;
      padding-block: clamp(56px, 7vw, 88px);
      background: var(--c-dark);
      color: #b9cbc4;
      isolation: isolate;

      &::before {
        content: '';
        position: absolute;
        inset: 0;
        z-index: -1;
        opacity: 0.5;
        background-image: radial-gradient(rgba(127, 220, 185, 0.22) 1px, transparent 1px);
        background-size: 22px 22px;
        mask-image: linear-gradient(90deg, #000, transparent 70%);
      }
    }

    .glow {
      position: absolute;
      z-index: -1;
      right: -10%;
      top: -60%;
      width: 640px;
      height: 640px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(37, 142, 111, 0.45), transparent 65%);
    }

    .inner {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 2rem 3rem;
      flex-wrap: wrap;
    }

    .text { max-width: 620px; }
    .eyebrow { color: #7fdcb9; }
    h2 { color: #fff; margin-bottom: 0.5rem; }
    p { margin: 0; }

    .actions { display: flex; flex-direction: column; align-items: flex-start; gap: 1rem; }

    .channels {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem 1.25rem;
      font-size: 0.92rem;

      a { display: inline-flex; align-items: center; gap: 0.4rem; color: #b9cbc4; &:hover { color: #fff; } }
      app-icon { color: #7fdcb9; }
    }
  `,
})
export class CtaBand {
  readonly title = input('¿Tienes dudas sobre algún trámite?');
  readonly text = input('Nuestro equipo te orienta sobre requisitos y documentos. Escríbenos o llámanos.');

  protected readonly info = CONTACT_INFO;
}
