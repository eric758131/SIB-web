import { ChangeDetectionStrategy, Component, DestroyRef, PLATFORM_ID, inject, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { filter } from 'rxjs';
import { Icon } from '../../shared/icon';
import { CONTACT_INFO, LOGO_URL, MAIN_MENU, SOCIAL_LINKS, VISADOS_LINKS } from '../../core/site-content';

@Component({
  selector: 'app-public-layout',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, Icon],
  templateUrl: './public-layout.html',
  styleUrl: './public-layout.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    '(window:scroll)': 'onScroll()',
    '(document:click)': 'onDocumentClick($event)',
    '(document:keydown.escape)': 'visadosOpen.set(false)',
  },
})
export class PublicLayout {
  protected readonly menu = MAIN_MENU;
  protected readonly logo = LOGO_URL;
  protected readonly visados = VISADOS_LINKS;
  protected readonly contact = CONTACT_INFO;
  protected readonly social = SOCIAL_LINKS;
  protected readonly year = new Date().getFullYear();

  protected readonly menuOpen = signal(false);
  protected readonly openSubmenu = signal<string | null>(null);
  protected readonly scrolled = signal(false);
  protected readonly visadosOpen = signal(false);

  private isBrowser = isPlatformBrowser(inject(PLATFORM_ID));

  constructor() {
    const sub = inject(Router)
      .events.pipe(filter((e) => e instanceof NavigationEnd))
      .subscribe(() => {
        this.menuOpen.set(false);
        this.openSubmenu.set(null);
        this.visadosOpen.set(false);
      });
    inject(DestroyRef).onDestroy(() => sub.unsubscribe());
  }

  protected onScroll() {
    if (this.isBrowser) this.scrolled.set(window.scrollY > 40);
  }

  protected toggleMenu() {
    this.menuOpen.update((v) => !v);
  }

  protected toggleSubmenu(label: string) {
    this.openSubmenu.update((current) => (current === label ? null : label));
  }

  protected toggleVisados() {
    this.visadosOpen.update((v) => !v);
  }

  /** Closes the Visados menu when clicking anywhere outside it. */
  protected onDocumentClick(event: MouseEvent) {
    if (!(event.target as HTMLElement).closest('.visados')) this.visadosOpen.set(false);
  }

  protected scrollTop() {
    if (this.isBrowser) window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}
