import { RenderMode, ServerRoute } from '@angular/ssr';

export const serverRoutes: ServerRoute[] = [
  // The admin panel depends on the token stored in the browser.
  { path: 'admin', renderMode: RenderMode.Client },
  { path: 'admin/**', renderMode: RenderMode.Client },
  // Public pages are rendered on each request so new posts show up immediately (and SEO sees them).
  { path: '**', renderMode: RenderMode.Server },
];
