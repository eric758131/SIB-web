/**
 * Content of the site's fixed pages
 * (Inicio, Acerca de, Servicios, Contacto, Comité Electoral, Convocatorias, ...).
 */
import { MEDIA_URL } from './config';

const media = (path: string) => `${MEDIA_URL}/${path}`;

export const LOGO_URL = media('images/logo.png');
export const HERO_IMAGE = media('images/hero.jpg');
/** External systems listed under the "Visados" header button. */
export const VISADOS_LINKS = [
  { label: 'Visados', host: 'visados.siblpz.org.bo', url: 'https://visados.siblpz.org.bo/', icon: 'stamp' },
  { label: 'Carátulas', host: 'caratulas.siblpz.org.bo', url: 'https://caratulas.siblpz.org.bo/', icon: 'file' },
];

export interface NavItem {
  label: string;
  path: string;
  children?: NavItem[];
}

/** Main menu of the public site. */
export const MAIN_MENU: NavItem[] = [
  { label: 'Inicio', path: '/' },
  {
    label: 'Acerca de',
    path: '/about',
    children: [{ label: 'Documentos Institucionales SIB La Paz', path: '/documentos-institucionales-sib-la-paz' }],
  },
  { label: 'Servicios', path: '/services' },
  { label: 'Convocatorias SIB Nacional', path: '/convocatorias-sib-nacional' },
  { label: 'Noticias', path: '/blog' },
  { label: 'Contacto', path: '/contact' },
  { label: 'Comité Electoral', path: '/comite-electoral' },
  { label: 'Convocatorias', path: '/convocatorias' },
];

export const CONTACT_INFO = {
  phone: '69719935',
  email: 'info@siblpz.org.bo',
  address: 'Calle Batallón Colorados No 24, Edif. "El Cóndor", Piso 9 of. 901- 904, La Paz, Bolivia',
};

export const SOCIAL_LINKS = [
  { name: 'Facebook', icon: 'facebook', url: 'https://www.facebook.com/share/1Af11eX5px/' },
  { name: 'Instagram', icon: 'instagram', url: 'https://www.instagram.com/sib_lapaz' },
  { name: 'YouTube', icon: 'youtube', url: 'https://www.youtube.com/@SIB%20La%20Paz' },
];

export const ABOUT = {
  commitmentTitle: 'Compromiso con la Ingeniería en Bolivia',
  commitment:
    'En SIB La Paz, hemos logrado un impacto significativo en el desarrollo de la ingeniería, promoviendo la ética y la profesionalidad entre nuestros miembros. Nos esforzamos por ser un referente en la región, facilitando recursos y oportunidades valiosas para nuestros afiliados.',
  organization:
    'Nuestra organización se dedica a fomentar el desarrollo técnico y social de la ingeniería en La Paz. A través de eventos, capacitaciones y servicios, apoyamos a nuestros miembros en su crecimiento profesional y en la mejora continua de su práctica.',
  stats: [
    { value: 10, suffix: '+', label: 'Años de Experiencia' },
    { value: 98, suffix: '%', label: 'Tasa de Satisfacción del Cliente' },
    { value: 10, suffix: 'K+', label: 'Fotos Entregadas' },
    { value: 200, suffix: '+', label: 'Proyectos Completados' },
  ],
  approachTitle: 'Enfoque Profesional y Ético en Ingeniería',
  approach:
    'Adoptamos un enfoque centrado en la ética y la responsabilidad social, garantizando que nuestros servicios y actividades promocionen el avance sostenible de la ingeniería en Bolivia, creando un ambiente colaborativo entre nuestros socios.',
  mission:
    'Nuestra misión es impulsar el desarrollo técnico y ético de la ingeniería en Bolivia, promoviendo la excelencia profesional y el compromiso social entre nuestros miembros para contribuir al bienestar y progreso de la región.',
  awards: [
    { date: 'Ene 2014', title: 'Premio a la Innovación' },
    { date: 'May 2016', title: 'Reconocimiento a la Excelencia' },
    { date: 'Abr 2018', title: 'Premio Nacional de Ingeniería' },
    { date: 'Oct 2020', title: 'Distinción por Compromiso Social' },
  ],
  historyTitle: 'Nuestra Historia y Trayectoria en Ingeniería',
  history:
    'Desde nuestra fundación, SIB La Paz ha sido pionera en la promoción de estándares éticos y técnicos en la ingeniería. A lo largo de los años, hemos crecido y evolucionado, impulsando iniciativas que fortalecen nuestra comunidad y apoyan a nuestros ingenieros tanto en su desarrollo profesional como personal.',
};

export interface Tramite {
  code: string;
  title: string;
  slug: string;
  image: string;
}

/** Registration procedures (Servicios > Requisitos de Inscripción) and their requirement sheets. */
export const TRAMITES: Tramite[] = [
  {
    code: 'FORM A-01',
    title: 'Trámite de Inscripción Ingenieros titulados en universidades nacionales',
    slug: 'tramite-de-inscripcion-ingenieros-titulados-en-universidades-nacionales',
    image: media('tramites/inscripcion-nacionales.jpg'),
  },
  {
    code: 'FORM A-02',
    title: 'Trámite de Inscripción ingenieros titulados en universidades del exterior',
    slug: 'tramite-de-inscripcion-ingenieros-titulados-en-universidades-del-exterior',
    image: media('tramites/inscripcion-exterior.jpg'),
  },
  {
    code: 'FORM A-03',
    title: 'Trámite de Inscripción de profesionales Técnicos titulados en universidades o Institutos superiores autorizados Nacionales',
    slug: 'tramite-de-inscripcion-de-profesionales-tecnicos-titulados-en-universidades-o-institutos-superiores-autorizados-nacionales',
    image: media('tramites/inscripcion-tecnicos-nacionales.jpg'),
  },
  {
    code: 'FORM A-04',
    title: 'Trámite de Inscripción de profesionales Técnicos titulados en universidades o institutos superiores del exterior',
    slug: 'tramite-de-inscripcion-de-profesionales-tecnicos-titulados-en-universidades-o-institutos-superiores-del-exterior',
    image: media('tramites/inscripcion-tecnicos-exterior.jpg'),
  },
  {
    code: 'FORM A-05',
    title: 'Trámite de Renovación, Actualización y duplicados de la credencial profesional',
    slug: 'tramite-de-renovacion-actualizacion-y-duplicados-de-la-credencial-profesional',
    image: media('tramites/renovacion-credencial.jpg'),
  },
  {
    code: 'FORM A-06',
    title: 'Trámite de licencia de Extranjero con vigencia de un año',
    slug: 'tramite-de-licencia-de-extranjero-con-vigencia-de-un-ano',
    image: media('tramites/licencia-extranjero.jpg'),
  },
];

export const SERVICES = {
  tribunal: {
    title: 'Informe de Tribunal Externo',
    linkLabel: 'Descargar Modelo de Informe de Tribunal Externo',
    file: media('documentos/informe-tribunal-externo.docx'),
    image: media('portadas/informe-tribunal-externo.jpg'),
  },
  items: [
    {
      title: 'Legalización de Documentos',
      text: 'Brindamos asistencia en la legalización de documentos, incluyendo visados de planos y otros trámites técnicos. Nuestro equipo garantiza el cumplimiento de las normativas y requisitos establecidos para facilitar a los socios sus gestiones profesionales.',
    },
    {
      title: 'Consultas Técnicas',
      text: 'Ofrecemos un servicio de consultas técnicas y éticas donde nuestros socios pueden obtener asesoría sobre normativas, mejores prácticas y resolver dudas relacionadas con su ejercicio profesional. Este apoyo es fundamental para mantener un estándar ético en la profesión.',
    },
    {
      title: 'Capacitaciones y Eventos',
      text: 'Organizamos capacitaciones y eventos que actualizarán a nuestros socios en tecnologías emergentes y tendencias del sector, promoviendo un aprendizaje continuo y colaboración en la comunidad de ingenieros.',
    },
  ],
};

export interface SiteDocument {
  label: string;
  title: string;
  description?: string;
  file: string;
  thumbnail: string;
}

export interface DocumentPage {
  title: string;
  intro?: string;
  documents: SiteDocument[];
}

/** Pages that list downloadable PDFs, keyed by their URL slug. */
export const DOCUMENT_PAGES: Record<string, DocumentPage> = {
  'comite-electoral': {
    title: 'Comité Electoral SIB La Paz',
    documents: [
      {
        label: 'Comité Electoral',
        title: 'Convocatoria',
        description: 'Convocatoria a Elecciones para Directorio Departamental SIB La Paz Gestión 2026 - 2028',
        file: media('documentos/comite-electoral-convocatoria.pdf'),
        thumbnail: media('portadas/comite-electoral-convocatoria.png'),
      },
      {
        label: 'Comité Electoral',
        title: 'Reglamento',
        description: 'Reglamento de Elecciones del Directorio Departamental Gestión 2026 - 2028',
        file: media('documentos/comite-electoral-reglamento.pdf'),
        thumbnail: media('portadas/comite-electoral-reglamento.png'),
      },
    ],
  },
  convocatorias: {
    title: 'Convocatorias',
    documents: [
      {
        label: 'Convocatoria Pública',
        title: 'Gerente Técnico Administrativo',
        file: media('documentos/convocatoria-gerente-tecnico.pdf'),
        thumbnail: media('portadas/convocatoria-gerente-tecnico.jpg'),
      },
    ],
  },
  'convocatorias-sib-nacional': {
    title: 'Convocatorias SIB Nacional',
    documents: [
      {
        label: 'Sociedad de Ingenieros de Bolivia',
        title: 'Convocatoria',
        description: 'Convocatoria a Inscripción de Fórmulas Electorales (Comité Electoral Nacional)',
        file: media('documentos/nacional-inscripcion-formulas.pdf'),
        thumbnail: media('portadas/nacional-inscripcion-formulas.jpg'),
      },
      {
        label: 'Sociedad de Ingenieros de Bolivia',
        title: 'Convocatoria',
        description: 'Segunda Convocatoria a Elecciones del Directorio Nacional de la SIB Gestión 2026 - 2028',
        file: media('documentos/nacional-segunda-convocatoria-elecciones.pdf'),
        thumbnail: media('portadas/nacional-segunda-convocatoria-elecciones.jpg'),
      },
      {
        label: 'Sociedad de Ingenieros de Bolivia',
        title: 'Convocatoria',
        description: 'Segunda Convocatoria a la XVII Asamblea Nacional Ordinaria de Representantes de la SIB',
        file: media('documentos/nacional-segunda-convocatoria-asamblea.pdf'),
        thumbnail: media('portadas/nacional-segunda-convocatoria-asamblea.jpg'),
      },
    ],
  },
  'documentos-institucionales-sib-la-paz': {
    title: 'Documentos Institucionales SIB La Paz',
    documents: [
      {
        label: 'Documentos Institucionales',
        title: 'Estatuto Orgánico y Reglamento',
        description: 'Sociedad de Ingenieros de Bolivia Departamental La Paz',
        file: media('documentos/estatuto-sib-la-paz.pdf'),
        thumbnail: media('portadas/estatuto-sib-la-paz.jpg'),
      },
    ],
  },
};

export const FAQ = [
  {
    question: '¿Cuáles son los beneficios de ser socio?',
    answer: 'Los socios disfrutan de servicios exclusivos, capacitaciones y acceso a un network profesional en la ingeniería.',
  },
  {
    question: '¿Qué eventos organiza la SIB La Paz?',
    answer: 'Organizamos conferencias, talleres y charlas sobre diversas temáticas de actualidad en el ámbito de la ingeniería.',
  },
  {
    question: '¿Qué trámites puedo realizar como socio?',
    answer: 'Los socios pueden solicitar certificados de membresía, legalizaciones y realizar consultas técnicas de manera sencilla.',
  },
  {
    question: '¿Cómo puedo afiliarme a la SIB La Paz?',
    answer: 'Puede completar el formulario en línea disponible en nuestra sección de afiliación para iniciar el proceso.',
  },
  {
    question: '¿Cómo me actualizo sobre noticias y eventos?',
    answer: 'Puede suscribirse a nuestro boletín institucional para recibir actualizaciones sobre eventos y noticias importantes.',
  },
  {
    question: '¿Cómo puedo estar seguro de la seguridad de mis datos?',
    answer: 'Implementamos medidas de ciberseguridad, incluyendo encriptación y autenticaciones seguras para proteger la información de nuestros socios.',
  },
];
