import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from './auth.service';
import { API_URL } from './config';

/** Adds the panel token to admin API calls and sends the user to the login on 401. */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const isAdminCall = req.url.startsWith(`${API_URL}/admin`);
  const token = auth.token;

  const request = isAdminCall && token ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }) : req;

  return next(request).pipe(
    catchError((error: HttpErrorResponse) => {
      if (isAdminCall && error.status === 401) {
        auth.clear();
        router.navigate(['/admin/login'], { queryParams: { expirada: 1 } });
      }
      return throwError(() => error);
    }),
  );
};
