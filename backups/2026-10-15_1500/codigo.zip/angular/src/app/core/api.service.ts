import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { API_URL } from './config';
import { CategoryRef, Paginated, Post, PostDetail } from './models';

/** Public site endpoints. */
@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);

  posts(options: { page?: number; perPage?: number; q?: string; category?: string } = {}) {
    let params = new HttpParams()
      .set('page', options.page ?? 1)
      .set('per_page', options.perPage ?? 9);
    if (options.q) params = params.set('q', options.q);
    if (options.category) params = params.set('category', options.category);

    return this.http.get<Paginated<Post>>(`${API_URL}/posts`, { params });
  }

  post(slug: string) {
    return this.http.get<PostDetail>(`${API_URL}/posts/${encodeURIComponent(slug)}`);
  }

  categories() {
    return this.http.get<(CategoryRef & { count: number })[]>(`${API_URL}/categories`);
  }

  contact(data: { name: string; email: string; phone: string; message: string; website: string }) {
    return this.http.post<{ message: string }>(`${API_URL}/contact`, data);
  }
}
