export type PostStatus = 'publish' | 'draft' | 'pending' | 'future' | 'private' | 'trash';

export interface CategoryRef {
  id: number;
  name: string;
  slug: string;
}

export interface Category extends CategoryRef {
  description?: string;
  count: number;
  is_default?: boolean;
}

export interface Post {
  id: number;
  title: string;
  slug: string;
  excerpt: string;
  manual_excerpt?: string;
  content?: string;
  cover_image: string | null;
  thumbnail_id: number | null;
  status: PostStatus;
  published_at: string | null;
  updated_at: string | null;
  categories: CategoryRef[];
  author?: { id: number; name: string } | null;
}

export interface PostLink {
  title: string;
  slug: string;
}

export interface PostDetail {
  data: Post;
  related: Post[];
  previous: PostLink | null;
  next: PostLink | null;
}

export interface PageMeta {
  current_page: number;
  last_page: number;
  per_page: number;
  total: number;
}

export interface Paginated<T> {
  data: T[];
  meta: PageMeta;
}

export interface User {
  id: number;
  username: string;
  name: string;
  email: string;
  role: string | null;
  role_label: string;
  can_use_panel: boolean;
  /** Only present for the signed-in user. */
  permissions?: string[];
  posts_count: number | null;
  registered_at: string | null;
  last_login_at: string | null;
}

export interface Role {
  id: number;
  name: string;
  label: string;
  is_system: boolean;
  users_count: number;
  permissions: string[];
}

export interface PermissionDef {
  name: string;
  group: string;
  label: string;
}

export interface Activity {
  id: number;
  log: string;
  event: string | null;
  description: string;
  subject_id: number | null;
  subject_title: string | null;
  properties: Record<string, unknown>;
  causer: { id: number; name: string } | null;
  created_at: string;
}

export interface RoleOption {
  value: string;
  label: string;
}

export interface Message {
  id: number;
  form_id: number;
  name: string | null;
  email: string | null;
  phone: string | null;
  message: string | null;
  fields: { label: string; value: string }[];
  status: 'unread' | 'read' | 'trash';
  device: string | null;
  browser: string | null;
  created_at: string | null;
}

export interface Media {
  id: number;
  title: string;
  url: string;
  mime_type: string;
  is_image: boolean;
  uploaded_at: string | null;
}

export interface Dashboard {
  stats: {
    published: number;
    drafts: number;
    scheduled: number;
    categories: number;
    unread_messages: number | null;
    users: number | null;
  };
  posts_per_month: { month: string; label: string; total: number }[];
  latest_posts: Post[];
  latest_messages: Message[];
  activity: Activity[];
}

export interface PostInput {
  title: string;
  slug: string | null;
  content: string;
  excerpt: string | null;
  status: 'publish' | 'draft' | 'pending';
  published_at: string | null;
  categories: number[];
  thumbnail_id: number | null;
}
