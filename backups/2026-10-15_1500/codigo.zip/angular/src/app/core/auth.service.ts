import { HttpClient } from '@angular/common/http';
import { Injectable, PLATFORM_ID, computed, inject, signal } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router } from '@angular/router';
import { Observable, catchError, map, of, tap } from 'rxjs';
import { API_URL } from './config';
import { User } from './models';

const TOKEN_KEY = 'sib_panel_token';

/** Permission names defined in Laravel (App\Support\PanelPermissions). */
export type Permission =
  | 'publicaciones.crear'
  | 'publicaciones.ver_todas'
  | 'publicaciones.publicar'
  | 'publicaciones.eliminar'
  | 'publicaciones.eliminar_definitivo'
  | 'categorias.gestionar'
  | 'medios.subir'
  | 'mensajes.gestionar'
  | 'usuarios.gestionar'
  | 'roles.gestionar'
  | 'actividad.ver';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private router = inject(Router);
  private isBrowser = isPlatformBrowser(inject(PLATFORM_ID));

  readonly user = signal<User | null>(null);
  private readonly permissions = computed(() => new Set(this.user()?.permissions ?? []));

  /** Whether the signed-in user has a Spatie permission. */
  can(permission: Permission): boolean {
    return this.permissions().has(permission);
  }

  get token(): string | null {
    if (!this.isBrowser) return null;
    try {
      return localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  }

  private set token(value: string | null) {
    if (!this.isBrowser) return;
    try {
      if (value) localStorage.setItem(TOKEN_KEY, value);
      else localStorage.removeItem(TOKEN_KEY);
    } catch {
      // Storage unavailable (private mode): the session lasts until reload.
    }
  }

  login(login: string, password: string) {
    return this.http
      .post<{ token: string; user: User }>(`${API_URL}/auth/login`, { login, password })
      .pipe(
        tap(({ token, user }) => {
          this.token = token;
          this.user.set(user);
        }),
      );
  }

  /** Load the signed-in user once; resolves to false when there is no valid session. */
  ensureUser(): Observable<boolean> {
    if (this.user()) return of(true);
    if (!this.token) return of(false);

    return this.http.get<{ data: User }>(`${API_URL}/admin/me`).pipe(
      tap(({ data }) => this.user.set(data)),
      map(() => true),
      catchError(() => {
        this.clear();
        return of(false);
      }),
    );
  }

  /** Re-read the user (e.g. after changing roles, so permissions are current). */
  refresh() {
    this.http.get<{ data: User }>(`${API_URL}/admin/me`).subscribe({ next: ({ data }) => this.user.set(data) });
  }

  logout() {
    const done = () => {
      this.clear();
      this.router.navigate(['/admin/login']);
    };
    this.http.post(`${API_URL}/admin/logout`, {}).subscribe({ next: done, error: done });
  }

  /** Forget the session locally (expired token, 401...). */
  clear() {
    this.token = null;
    this.user.set(null);
  }
}
