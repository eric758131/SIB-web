import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { API_URL } from './config';
import {
  Activity,
  Category,
  PermissionDef,
  Role,
  Dashboard,
  Media,
  Message,
  Paginated,
  Post,
  PostInput,
  RoleOption,
  User,
} from './models';

const ADMIN = `${API_URL}/admin`;

function toParams(values: Record<string, string | number | null | undefined>) {
  let params = new HttpParams();
  for (const [key, value] of Object.entries(values)) {
    if (value !== null && value !== undefined && value !== '') params = params.set(key, value);
  }
  return params;
}

/** Admin panel endpoints (require a signed-in user). */
@Injectable({ providedIn: 'root' })
export class AdminApiService {
  private http = inject(HttpClient);

  dashboard() {
    return this.http.get<Dashboard>(`${ADMIN}/dashboard`);
  }

  // Posts
  posts(filters: { status?: string; q?: string; category?: number | null; page?: number }) {
    return this.http.get<Paginated<Post> & { counts: Record<string, number> }>(`${ADMIN}/posts`, {
      params: toParams({ ...filters, per_page: 15 }),
    });
  }

  post(id: number) {
    return this.http.get<{ data: Post; history: Activity[] }>(`${ADMIN}/posts/${id}`);
  }

  createPost(input: PostInput) {
    return this.http.post<{ data: Post; history: Activity[] }>(`${ADMIN}/posts`, input);
  }

  updatePost(id: number, input: PostInput) {
    return this.http.put<{ data: Post; history: Activity[] }>(`${ADMIN}/posts/${id}`, input);
  }

  trashPost(id: number) {
    return this.http.delete<void>(`${ADMIN}/posts/${id}`);
  }

  deletePost(id: number) {
    return this.http.delete<void>(`${ADMIN}/posts/${id}`, { params: { force: 1 } });
  }

  restorePost(id: number) {
    return this.http.post<{ data: Post }>(`${ADMIN}/posts/${id}/restore`, {});
  }

  // Categories
  categories() {
    return this.http.get<Category[]>(`${ADMIN}/categories`);
  }

  createCategory(data: { name: string; slug?: string; description?: string }) {
    return this.http.post<Category>(`${ADMIN}/categories`, data);
  }

  updateCategory(id: number, data: { name: string; slug?: string; description?: string }) {
    return this.http.put<Category>(`${ADMIN}/categories/${id}`, data);
  }

  deleteCategory(id: number) {
    return this.http.delete<void>(`${ADMIN}/categories/${id}`);
  }

  // Media
  media(filters: { type?: string; q?: string; page?: number }) {
    return this.http.get<Paginated<Media>>(`${ADMIN}/media`, { params: toParams(filters) });
  }

  upload(file: File) {
    const body = new FormData();
    body.append('file', file);
    return this.http.post<Media>(`${ADMIN}/media`, body);
  }

  // Messages
  messages(filters: { status?: string; q?: string; page?: number }) {
    return this.http.get<Paginated<Message> & { counts: Record<string, number> }>(`${ADMIN}/messages`, {
      params: toParams(filters),
    });
  }

  message(id: number) {
    return this.http.get<{ data: Message }>(`${ADMIN}/messages/${id}`);
  }

  setMessageStatus(id: number, status: Message['status']) {
    return this.http.put<{ data: Message }>(`${ADMIN}/messages/${id}`, { status });
  }

  deleteMessage(id: number) {
    return this.http.delete<void>(`${ADMIN}/messages/${id}`);
  }

  // Users
  users(q = '') {
    return this.http.get<{ data: User[]; roles: RoleOption[] }>(`${ADMIN}/users`, { params: toParams({ q }) });
  }

  createUser(data: Record<string, unknown>) {
    return this.http.post<{ data: User }>(`${ADMIN}/users`, data);
  }

  updateUser(id: number, data: Record<string, unknown>) {
    return this.http.put<{ data: User }>(`${ADMIN}/users/${id}`, data);
  }

  deleteUser(id: number) {
    return this.http.delete<void>(`${ADMIN}/users/${id}`);
  }

  // Roles & permissions (spatie/laravel-permission)
  roles() {
    return this.http.get<{ roles: Role[]; permissions: PermissionDef[] }>(`${ADMIN}/roles`);
  }

  createRole(data: { name: string; permissions: string[] }) {
    return this.http.post<Role>(`${ADMIN}/roles`, data);
  }

  updateRole(id: number, data: { name: string; permissions: string[] }) {
    return this.http.put<Role>(`${ADMIN}/roles/${id}`, data);
  }

  deleteRole(id: number) {
    return this.http.delete<void>(`${ADMIN}/roles/${id}`);
  }

  // Activity log (spatie/laravel-activitylog)
  activity(filters: { log?: string; user?: number | null; q?: string; page?: number }) {
    return this.http.get<
      Paginated<Activity> & { logs: RoleOption[]; users: { id: number; name: string }[] }
    >(`${ADMIN}/activity`, { params: toParams(filters) });
  }

  // Own profile
  updateProfile(data: Record<string, unknown>) {
    return this.http.put<{ data: User }>(`${ADMIN}/me`, data);
  }
}
