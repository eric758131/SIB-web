import { Injectable, inject } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { SITE_NAME } from './config';

@Injectable({ providedIn: 'root' })
export class SeoService {
  private title = inject(Title);
  private meta = inject(Meta);

  set(pageTitle: string, description?: string, image?: string | null) {
    const full = pageTitle ? `${pageTitle} – ${SITE_NAME}` : SITE_NAME;
    this.title.setTitle(full);
    this.meta.updateTag({ property: 'og:title', content: full });

    if (description) {
      this.meta.updateTag({ name: 'description', content: description });
      this.meta.updateTag({ property: 'og:description', content: description });
    }
    if (image) {
      this.meta.updateTag({ property: 'og:image', content: image });
    }
  }
}
