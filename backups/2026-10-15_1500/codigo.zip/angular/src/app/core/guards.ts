import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { map } from 'rxjs';
import { AuthService, Permission } from './auth.service';

export const authGuard: CanActivateFn = (_route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  return auth
    .ensureUser()
    .pipe(map((ok) => ok || router.createUrlTree(['/admin/login'], { queryParams: { volver: state.url } })));
};

export const guestGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  return auth.ensureUser().pipe(map((ok) => (ok ? router.createUrlTree(['/admin']) : true)));
};

/** Only users with the given Spatie permission. */
export function permissionGuard(permission: Permission): CanActivateFn {
  return () => inject(AuthService).can(permission) || inject(Router).createUrlTree(['/admin']);
}
