/**
 * Laravel API base URL. The browser uses the same-origin `/api` path (dev-server proxy,
 * or the Express server in production), so the site works from any domain.
 * Server-side rendering calls Laravel directly.
 */
export const API_URL = typeof window === 'undefined' ? 'http://127.0.0.1:8000/api' : '/api';

/** Images and documents of the fixed pages, served from public/media. */
export const MEDIA_URL = '/media';

export const SITE_NAME = 'SIB La Paz';
