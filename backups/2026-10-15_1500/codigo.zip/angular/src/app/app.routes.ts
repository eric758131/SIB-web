import { Routes } from '@angular/router';
import { authGuard, guestGuard, permissionGuard } from './core/guards';
import { TRAMITES } from './core/site-content';
import { PublicLayout } from './public/layout/public-layout';

/** Public URLs keep the same paths the site has always used. */
export const routes: Routes = [
  {
    path: 'admin/login',
    canActivate: [guestGuard],
    loadComponent: () => import('./admin/login/login').then((m) => m.Login),
    title: 'Iniciar sesión – Panel SIB La Paz',
  },
  {
    path: 'admin',
    canActivate: [authGuard],
    loadComponent: () => import('./admin/layout/admin-layout').then((m) => m.AdminLayout),
    children: [
      { path: '', loadComponent: () => import('./admin/dashboard/dashboard').then((m) => m.Dashboard), title: 'Escritorio – Panel SIB La Paz' },
      { path: 'publicaciones', canActivate: [permissionGuard('publicaciones.crear')], loadComponent: () => import('./admin/posts/post-list').then((m) => m.PostList), title: 'Publicaciones – Panel SIB La Paz' },
      { path: 'publicaciones/nueva', canActivate: [permissionGuard('publicaciones.crear')], loadComponent: () => import('./admin/posts/post-form').then((m) => m.PostForm), title: 'Nueva publicación – Panel SIB La Paz' },
      { path: 'publicaciones/:id', canActivate: [permissionGuard('publicaciones.crear')], loadComponent: () => import('./admin/posts/post-form').then((m) => m.PostForm), title: 'Editar publicación – Panel SIB La Paz' },
      { path: 'medios', loadComponent: () => import('./admin/media/media-library').then((m) => m.MediaLibrary), title: 'Medios – Panel SIB La Paz' },
      { path: 'categorias', canActivate: [permissionGuard('categorias.gestionar')], loadComponent: () => import('./admin/categories/categories').then((m) => m.Categories), title: 'Categorías – Panel SIB La Paz' },
      { path: 'mensajes', canActivate: [permissionGuard('mensajes.gestionar')], loadComponent: () => import('./admin/messages/messages').then((m) => m.Messages), title: 'Mensajes – Panel SIB La Paz' },
      { path: 'usuarios', canActivate: [permissionGuard('usuarios.gestionar')], loadComponent: () => import('./admin/users/users').then((m) => m.Users), title: 'Usuarios – Panel SIB La Paz' },
      { path: 'roles', canActivate: [permissionGuard('roles.gestionar')], loadComponent: () => import('./admin/roles/roles').then((m) => m.Roles), title: 'Roles y permisos – Panel SIB La Paz' },
      { path: 'actividad', canActivate: [permissionGuard('actividad.ver')], loadComponent: () => import('./admin/activity/activity-log').then((m) => m.ActivityLog), title: 'Actividad – Panel SIB La Paz' },
      { path: 'perfil', loadComponent: () => import('./admin/profile/profile').then((m) => m.Profile), title: 'Mi perfil – Panel SIB La Paz' },
    ],
  },
  {
    path: '',
    component: PublicLayout,
    children: [
      { path: '', loadComponent: () => import('./public/pages/home/home').then((m) => m.Home) },
      { path: 'about', loadComponent: () => import('./public/pages/about/about').then((m) => m.About) },
      { path: 'services', loadComponent: () => import('./public/pages/services/services').then((m) => m.Services) },
      { path: 'contact', loadComponent: () => import('./public/pages/contact/contact').then((m) => m.Contact) },
      { path: 'blog', loadComponent: () => import('./public/pages/news/news-list').then((m) => m.NewsList) },
      ...['comite-electoral', 'convocatorias', 'convocatorias-sib-nacional', 'documentos-institucionales-sib-la-paz'].map((slug) => ({
        path: slug,
        loadComponent: () => import('./public/pages/documents/documents').then((m) => m.Documents),
        data: { page: slug },
      })),
      ...TRAMITES.map((t) => ({
        path: t.slug,
        loadComponent: () => import('./public/pages/tramite/tramite').then((m) => m.TramitePage),
        data: { tramite: t.slug },
      })),
      { path: '404', loadComponent: () => import('./public/pages/not-found/not-found').then((m) => m.NotFound) },
      // Anything else is a news item (/<slug>).
      { path: ':slug', loadComponent: () => import('./public/pages/news/post-detail').then((m) => m.PostDetail) },
    ],
  },
  { path: '**', redirectTo: '404' },
];
